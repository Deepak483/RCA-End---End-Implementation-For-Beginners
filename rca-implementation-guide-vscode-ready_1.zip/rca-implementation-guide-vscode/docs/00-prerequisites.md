# 00 — Prerequisites

Confirm these before starting Module 1.

## Access
- [ ] System Administrator profile (or equivalent) in the target org
- [ ] Revenue Cloud Advanced licenses provisioned by Salesforce for this org (check Setup → Company Information → check installed licenses, or ask your Salesforce AE if unsure)

## Tools (only needed for permission set automation, in Module 1)
- [ ] [Salesforce CLI](https://developer.salesforce.com/tools/salesforcecli) installed:
  ```bash
  npm install --global @salesforce/cli
  sf --version
  ```
- [ ] Authenticated to the target org:
  ```bash
  sf org login web --alias my-rca-org
  ```
  For production orgs use the same command — `sf` will prompt against `login.salesforce.com`. For sandboxes:
  ```bash
  sf org login web --alias my-rca-sandbox --instance-url https://test.salesforce.com
  ```
- [ ] Confirm you're pointed at the right org before doing anything else:
  ```bash
  sf org display --target-org my-rca-org
  ```

## Knowledge check
- **Not all Module 1 settings require manual Setup clicks.** 12 of the 18 settings deploy via Metadata API — see `modules/01-rca-setup-and-permissions/scripts/revenue-settings/`. Only 3 are genuinely manual with no toggle at all (#1 Release Update, #7 Asset flow — usually needs no action, #14 Constraints Engine content). 2 more (#8, #13) have a scriptable toggle but still need a manual build step on top (a Flow, and rule content). Full breakdown: `modules/01-rca-setup-and-permissions/01-enable-revenue-settings.md`.
- Permission set assignment can be scripted, but permission set **labels** (what you see in Setup) are not the same as their **API DeveloperNames** (what the CLI needs). `modules/01-rca-setup-and-permissions/scripts/README.md` shows how to look up the real names in your org before running anything.

Once these are checked, move to `intake/setup-questionnaire.md` if you haven't already, then `modules/01-rca-setup-and-permissions/01-enable-revenue-settings.md`.
