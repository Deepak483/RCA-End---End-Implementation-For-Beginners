# Roadmap — What's Built and What's Next

This repo is built directly from the Confluence page [RCA Implementation in new Org](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), one module (Confluence table row) at a time.

## Built

| Module (Confluence row) | Repo folder | Tickets/items |
|---|---|---|
| RCA Setup and Permissions | `modules/01-rca-setup-and-permissions/` | 3 |
| Product Setup | `modules/02-product-setup/` | 7 |
| Pricing Setup | `modules/03-pricing-setup/` | 4 |
| Quote Management | `modules/04-quote-management/` | 13 (12 tickets + 1 Confluence-only item) |
| Order Management | `modules/05-order-management/` | 3 |
| CLM | `modules/06-clm/` | 3 (2 tickets + 1 Confluence-only item) |
| Asset | `modules/07-asset/` | 1 (no Asana ticket) |
| Amendment and Renewals | `modules/08-amendment-and-renewals/` | 5 (3 tickets + 2 Confluence-only items) |

## Not yet built, in Confluence order

The `Module` custom field on Asana tickets in this project includes values not yet seen as their own dedicated Confluence row with tickets pulled: **Taxation, CRM Setup, Partner Portal, API, Data Migration, Release 256, Spring 26**. Some tickets tagged with these modules already surfaced incidentally while building other modules (e.g. "Address on Account" is tagged CRM Setup but lives in Module 4; the DRO ticket is tagged DRO but lives in Module 5's Order Management folder) — check for tickets tagged with a given Module value across the whole Asana project before assuming a dedicated module needs building from scratch.

## How to build the next module

Same pattern as Modules 1 and 2:
1. Confirm which Confluence row/tickets the user wants next.
2. Fetch each Asana ticket (`notes` + `custom_fields` + comments — the comments often have the real fix/gotcha, not just the original description).
3. If a ticket links out to its own Confluence page (like Usage Product Setup did), fetch that too — it usually has the actual step-by-step.
4. Write one doc per ticket: goal, data-source checkpoint if it creates records, confirmed steps, known issues from the ticket's comment history, validation checklist.
5. Write a module README: ticket table, dependency order, any module-wide data-source question, known blockers.
6. Update this file's "Built" table and `AGENT-PLAYBOOK.md`'s module list.
7. Re-run the full repo through `CHANGELOG.md` once validated against the current reference org.
