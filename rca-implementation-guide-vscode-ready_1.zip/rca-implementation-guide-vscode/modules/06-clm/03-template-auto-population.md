# 03 — Auto-Populate Template Based on CLM Type

Source: Confluence only — **no Asana ticket link exists for this item.**

## Goal

When a user creates a CLM document, the template selected for generation should automatically match the type chosen. Example: if the user creates an **Order Form** CLM, the system should default to the **Order Form template** — not present both MSA and Order Form as options.

## What we know vs. what needs confirming

The Confluence testing comment for this item describes it as only partially working at the time it was marked Done:
> "Both the option of MSA and Order form is coming despite selecting the OF option. Also, the option of selecting either of the form is coming when we create Contract through Quote button, but not through Create Contract Button on Order." — noted as **Resolved**, but with no detail on what the actual fix was.

**Practical implication:** treat this as needing verification in a new org rather than a confirmed working procedure. Specifically check:
- Does selecting a CLM type correctly filter to only that type's template (not show both)?
- Does behavior differ depending on whether the Contract is created via the **Quote button** vs. the **Create Contract button on Order**? The source ticket implies these two paths behaved differently — confirm both paths independently rather than assuming testing one covers the other.

## Recommended approach when doing this in a new org

1. Create the Contract from a Quote (via `01-contract-setup.md`'s button), selecting Order Form type — confirm only the Order Form template is offered.
2. Repeat via the **Create Contract button on Order** (a separate path) — confirm the same filtering behavior holds there too.
3. If either path shows both templates regardless of selection, the underlying fix (likely a filter on the template picker tied to the CLM type field) needs to be rebuilt for this org rather than assumed inherited.

## Validation
- [ ] Selecting Order Form CLM type on the Quote-based Contract button only offers the Order Form template
- [ ] Selecting MSA CLM type only offers the MSA template
- [ ] Same behavior confirmed independently via the Order-based Create Contract button
