# Module 6 — CLM (Contract Lifecycle Management)

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "CLM" (2 Asana tickets + 1 Confluence-only item).

**Prerequisite:** Module 1 enabled `enableContractMgmtPref` (Contract Management capability) and set up the initial context definition. This module builds the actual contract generation/approval/signature workflow on top of that.

## The 3 items

| # | Item | Asana ticket |
|---|---|---|
| 1 | Contract Setup (button, approval process, DocuSign, clause sets) | [1212442524927394](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927394) |
| 2 | Update Source Opportunity field on Contract | [1212442524927398](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927398) |
| 3 | Auto-populate Template based on CLM type (MSA vs. Order Form) | *(no Asana ticket — Confluence description only)* |

## Files in this module

- `01-contract-setup.md`
- `02-source-opportunity-field.md`
- `03-template-auto-population.md`

## Data source checkpoint

Ticket 1 references an **MSA document from a previous POC** used as the starting point for clause content. Ask the user: use that same reference MSA structure, or provide their own contract template/clause library? This is a genuine content decision, not just configuration.

## Known issues to flag upfront

- **Signer Date tag doesn't populate correctly in DocuSign** — noted as "not a blocker" by the implementer but never confirmed fully fixed. Test this specifically if date-stamped signatures matter for compliance.
- **Asset-Contract relationship** doesn't establish automatically even with the standard setting enabled — the source team closed the main ticket and opened a separate one for this specifically. If you need Assets linked to Contracts (common for renewal/amendment reporting), treat it as its own follow-up item, not something ticket 1 covers.
- **Document Template can be disabled by default** in a fresh org — if MSA generation doesn't appear as an option, check whether the relevant Document Template is simply inactive before assuming something else is broken.
