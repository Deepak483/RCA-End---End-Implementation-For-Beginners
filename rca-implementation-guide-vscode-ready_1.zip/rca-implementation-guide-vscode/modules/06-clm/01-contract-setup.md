# 01 — Contract Setup (Button, Approval, DocuSign, Clauses)

Source: [Asana ticket 1212442524927394](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927394) — "CLM - Contract generation, Approval, Clauses and Signature"

This ticket bundles 4 sub-tasks, all confirmed Done in the source org:
1. Create CLM Contract Button on Quote
2. Create Contract Approval Process
3. Create Document Clauses and Document Clauses Sets
4. Integrate DocuSign E-Signature

## Data source checkpoint

The source org used an **MSA document from a previous POC** as reference content for building clauses. Ask the user: reuse that same MSA structure (ask for the document if continuing this exact lineage), or build clauses from the user's own contract templates?

## Steps (confirmed from source ticket, at the level of detail available)

1. **Create CLM Contract Button on Quote** — adds a button that generates a Contract record from the Quote (this is the "Create Contract" flow referenced elsewhere as "Create CLM Document From Quote" — see `02-source-opportunity-field.md`, which modifies this same flow).
2. **Create Contract Approval Process** — standard Salesforce approval process on Contract.
3. **Create Document Clauses and Document Clauses Sets** — author clause records, then group them into Clause Sets that get pulled into generated documents. Use the reference MSA as source material for clause language if following option (a) above.
4. **Integrate DocuSign E-Signature** — connect DocuSign for the generated contract document.

## ⚠️ Known issues from testing

1. **Signer Date tag not working in DocuSign** — flagged as "not a blocker" at the time, but there's no confirmation it was later fixed. If your signature workflow depends on an accurate signer-date field, test this explicitly rather than assuming it's resolved.
2. **MSA document generation option didn't appear** initially — root cause was the **Document Template being disabled**. Check Setup for the relevant Document Template's active status before troubleshooting further if generation options seem to be missing.
3. **Asset-Contract relationship doesn't establish automatically.** There's a setting intended to create this relationship, but even with it enabled, assets weren't showing as associated with the Contract in testing. This was spun off into a **separate follow-up ticket** rather than resolved here — if you need Asset-Contract linkage (common for renewal reporting), plan for it as distinct work, not something this ticket delivers.

## Validation
- [ ] "Create Contract" button/action visible and functional on the Quote
- [ ] Contract Approval Process triggers correctly
- [ ] Clause Sets pull into generated contract documents correctly
- [ ] DocuSign integration sends for signature; verify the Signer Date tag specifically
- [ ] Document Template(s) needed for generation are Active, not just created
- [ ] If Asset-Contract linkage is needed: confirmed separately, not assumed from this ticket alone
