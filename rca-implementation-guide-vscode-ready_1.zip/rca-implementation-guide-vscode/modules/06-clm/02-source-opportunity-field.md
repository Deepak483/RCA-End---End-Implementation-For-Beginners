# 02 — Update Source Opportunity Field on Contract

Source: [Asana ticket 1212442524927398](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927398) — "Contract Management - Update Source Opportunity field on Contract"

## Goal

The **Source Opportunity** field on Contract should populate automatically, every time a Contract is created (no conditional criteria — always), reflecting the correct originating Opportunity. The field should be read-only after creation, and the solution must not disrupt existing contract creation flows, working for both RCA and RCB flows if applicable.

## Steps (confirmed from source ticket)

1. Create a new flow: **"Contract | Update Opportunity Source"**.
2. Modify the existing flow: **"Create CLM Document From Quote"** (the same flow the Contract button in `01-contract-setup.md` uses) to call the new flow and populate Source Opportunity.

**Components:** New Flow — Contract | Update Opportunity Source; Modified Flow — Create CLM Document From Quote.

## Validation
- [ ] Source Opportunity populates on every Contract, with no exceptions/conditions
- [ ] Field is read-only after Contract creation
- [ ] Existing contract creation flows (from `01-contract-setup.md`) still work correctly after this change
- [ ] Correct Opportunity is reflected — test with a Quote that has gone through amendments/renewals to confirm the *originating* Opportunity is captured, not a later one
