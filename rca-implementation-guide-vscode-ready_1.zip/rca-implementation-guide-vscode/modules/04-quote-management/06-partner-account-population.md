# 06 — Partner Account Population on Quote from Opportunity

Source: [Asana ticket 1212392771898683](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212392771898683) — "Quote Management - Partner / Distributor Account on Quote from Opportunity"

## Goal

Populate the Quote's Partner Account field from the Opportunity automatically. If the Opportunity has no partner account set, the user should still be able to add one directly on the Quote.

## Steps (confirmed from source ticket)

1. Create a custom object **Partner Product Discount** to store the partner-discount mapping (this is the same object used in Module 3, `04-partner-discount.md`).
2. Add a **Lookup to Account** field on Partner Product Discount, filtered to only show Accounts where Type = **Reseller** or **Distributor**.
3. Extend the "Create Quote" flow (from `01-quote-creation.md`) to include the Partner field, reading it from the Opportunity where available.

**Component:** Flow — Create Quote (screen flow, same one extended across multiple tickets in this module).

## ⚠️ Known issue — flagged for future rework

A later comment on this ticket raises an architecture concern: the partner-population logic currently lives in the **screen flow**, which only runs for manually-created quotes. If quotes get created another way (e.g. by Agentforce or an API integration), this logic won't run. **If the user's org creates quotes through any channel besides the New Quote button, this logic should move to a Quote Before-Save flow** (record-triggered) instead of staying screen-flow-only. Ask the user whether they anticipate non-UI quote creation before treating the screen-flow implementation as final.

## Validation
- [ ] Partner Account populates on the Quote automatically when set on the source Opportunity
- [ ] User can manually add a Partner Account on the Quote when the Opportunity has none
- [ ] Partner Account lookup filter correctly restricts to Reseller/Distributor account types only
- [ ] If quotes can be created outside the New Quote button in this org, confirm partner population still works there too
