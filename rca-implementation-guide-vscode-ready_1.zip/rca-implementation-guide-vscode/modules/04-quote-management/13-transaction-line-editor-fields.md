# 13 — Transaction Line Editor (TLE) Fields

Source: Confluence only — **no Asana ticket link exists for this item**, unlike every other item in this module. All detail here comes directly from the Confluence table row.

## Goal

Configure the Transaction Line Editor (the quote line grid) to show these fields:
- Product Name
- Quantity
- Start Date
- End Date
- List Price
- Adjustment Type
- Net Unit Price
- Net Total Price
- Total Price

## What we know vs. what needs confirming

The Confluence page's testing comment for this item notes the **Adjustment Type (discount) column was initially missing** from the TLE — the field existed but wasn't configured to display, and it wasn't clear at first whether the field even existed in the target org. This was eventually resolved, but the exact configuration steps (Setup path for TLE column configuration) weren't captured in Confluence the way other tickets captured their "Solution" section.

**Recommended approach when doing this in a new org:**
1. Go to **Setup → Object Manager → Quote Line** (or the equivalent Transaction Line object for your API version) → check for a "Transaction Line Editor Columns" or similar Revenue Cloud–specific configuration page (this is typically under Revenue Settings or a dedicated TLE config UI, not standard page layout).
2. Confirm all 9 fields listed above exist as fields on the object before configuring columns — the source org's issue was partly about not being sure a field existed in their specific org edition.
3. Add each field as a visible column in the order listed.

## Ask the user before proceeding

Since there's no ticket with confirmed steps, treat this as a **verify-in-your-org-first** item:
- Confirm your org's Revenue Cloud edition actually exposes an "Adjustment Type" field on quote lines (naming may differ by release).
- If a field from the list above doesn't exist, flag it rather than skipping silently — it may need a custom field, or may be named differently in the current release.

## Validation
- [ ] All 9 listed fields are visible as columns in the Transaction Line Editor
- [ ] Adjustment Type (discount) specifically confirmed visible — this was the field that went missing in the source org
- [ ] Values in each column look correct on a test quote with a discount applied (list price ≠ net price when a discount exists)
