# 05 — Quote Sync (Latest Quote Auto-Syncs with Opportunity)

Source: [Asana ticket 1212450081485102](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212450081485102) — "Quote Management - Latest Created Quote Is Automatically Synced with Opportunity"

## Goal

When multiple quotes exist under one Opportunity, the most recently created one should automatically become the **Synced Quote** on the Opportunity — no manual step required.

## Steps (confirmed from source ticket)

Add an **Update Records** element to the same "Create Quote" flow used in `01-quote-creation.md`, setting the Opportunity's Synced Quote ID field to the newly created Quote's ID.

**Component:** Flow — Create Quote (same flow, extended — not a new flow).

## Validation
- [ ] Creating a new quote on an Opportunity that already has a quote automatically replaces the synced quote with the new one
- [ ] No manual sync action is needed
- [ ] Opportunity's Quote-related fields (amount, etc., if synced) reflect the newly synced quote
