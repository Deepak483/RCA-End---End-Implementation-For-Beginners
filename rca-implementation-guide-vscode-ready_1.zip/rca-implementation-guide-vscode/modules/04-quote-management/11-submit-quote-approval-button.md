# 11 — Submit Quote for Approval (Button)

Source: [Asana ticket 1212346537317193](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317193) — "Quote Management - Create Submit Quote Approval"

## Goal

A **"Submit Quote for Approval"** button on the Quote that, once clicked:
- Creates the approval record(s) (feeding into `09-discount-approvals.md` and `10-payment-term-approval.md`'s logic)
- Locks the quote so the user can't make further changes

## Steps (confirmed from source ticket)

1. Create an **Auto-Launched Approval Process Flow**.
2. Create a **custom action** on Quote: "Submit for Approval".
3. Create an **LWC component** (`quoteApporvalLWC`) that calls the flow from the custom action.

**Components:** Flow — Quote Approval; Custom Action — Submit for Approval; LWC — quoteApporvalLWC.

## ⚠️ Known issue: locking didn't work initially

The button correctly triggered approval, but the record **didn't actually lock** — users could still edit a quote that was already submitted. Fix: restrict edit access so **only the Approver and System Administrator** can edit the record once submitted. If you're extending this later (e.g. adding more approver roles), make sure the lock logic covers every role that should retain edit access — it's an allow-list, not a simple "read-only" flag, so new roles won't automatically get access.

## Validation
- [ ] "Submit for Approval" button visible on the Quote
- [ ] Clicking it creates the expected approval record(s)
- [ ] Quote becomes uneditable to standard users immediately after submission
- [ ] Approver and System Administrator retain edit access on a submitted quote (this is intentional, not a bug)
