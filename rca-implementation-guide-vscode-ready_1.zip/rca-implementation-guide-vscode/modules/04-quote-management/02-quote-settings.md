# 02 — Quote Settings (Disable Specific Settings)

Source: [Asana ticket 1212206597402275](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212206597402275) — "Quote Management - Disable the Quote Settings"

This reinforces/confirms Module 1's setting #3 ("Set Up Quotes") — same underlying `QuoteSettings` metadata, described here from the quote-workflow angle.

## Goal

Disable specific Quote settings so quoting aligns with an **Opportunity-driven** quote creation model — i.e., quotes should always originate from an Opportunity (via the button in `01-quote-creation.md`), not be created standalone.

## Steps (confirmed from source ticket)

1. Change the Quote object's **Sharing Setting** to **Controlled by Parent**.
2. Go to **Setup → Quote Settings**:
   - **Disable Quotes** — leave unchecked (quotes stay enabled overall)
   - **Allow creating quotes without a related Opportunity** — uncheck (disable this specifically)

This matches Module 1's confirmed `QuoteSettings` values: `enableQuote = true`, `enableQuotesWithoutOppEnabled = false` — if you deployed Module 1's settings package already, this is already done. Use this ticket as the *why*: the team explicitly wants Opportunity-first quote creation, not a design accident.

## Validation
- [ ] Quote Sharing Setting = Controlled by Parent
- [ ] Attempting to create a quote with no related Opportunity is blocked or hidden as an option
- [ ] The "New Quote" button flow (`01-quote-creation.md`) still works correctly
