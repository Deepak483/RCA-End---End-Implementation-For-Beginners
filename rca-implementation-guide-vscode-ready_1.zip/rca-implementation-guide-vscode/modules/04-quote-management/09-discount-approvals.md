# 09 — Discount Approvals

Source: [Asana ticket 1212346537317187](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317187) — "Quote Management - Discount Approvals"

## Goal

Trigger an approval when a quote line's discount exceeds a category-based threshold.

## Data source checkpoint

If option (a): use the reference thresholds below. If option (b): ask for the user's own product categories/thresholds/approvers.

### Reference thresholds (source ticket)

| Category | Discount threshold | Approver |
|---|---|---|
| Hardware | > 20% | VP Sales |
| Software | > 30% | VP Sales |

### Reference notification format (source ticket)

```
Hello,
A quote has been submitted for approval. Please see the details below:
Quote #: {Quote Number}
Account: {Account Name}
Opportunity: {Opportunity Name}
Quote Amount: {Amount}

Quote Lines:
Line | Discount | Type
Line 1 | 20% | Hardware
Line 2 | 30% | Software

Please see the quote using the link: {quote link}
```

## Steps (confirmed from source ticket)

Implement this logic in the **Quote Approval** flow (the same flow extended in `10-payment-term-approval.md` — both approval triggers live in one flow, not separate ones).

**Component:** Flow — Quote Approval.

## ⚠️ Known issue: Product Family matters, not just Category

The approval logic checks **Product Family** (Hardware/Software), not the catalog **Category** (Bundle/Standalone from Module 2). Products added via Browse Catalog or Guided Selling from the Hardware/Software categories didn't trigger approval until their **Product Family** field was explicitly set to match. **Before testing this ticket, confirm every relevant product's Product Family field is set correctly** — a product can visually sit in the right catalog category and still not trigger the right approval if Family is wrong or blank.

## Validation
- [ ] Every Hardware/Software product has the correct Product Family value set (not just correct Category)
- [ ] A quote line with Hardware discount >20% triggers VP Sales approval
- [ ] A quote line with Software discount >30% triggers VP Sales approval
- [ ] Approver receives a notification matching the format above
- [ ] A quote line at or below the threshold does NOT trigger approval (test the boundary, e.g. exactly 20% for Hardware)
