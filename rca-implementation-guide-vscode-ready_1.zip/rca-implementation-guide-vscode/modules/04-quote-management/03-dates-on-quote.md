# 03 — Dates on Quote (End Date & Subscription Term)

Source: [Asana ticket 1212227290171262](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171262) — "Quote Management - End Date and Subscription Term population on Quote"

## Goal

- **Subscription Term** field with a default of 12 (months), shown as soon as a quote is created from the New Quote button.
- If the user leaves End Date blank, calculate it as Start Date + Subscription Term.
- If the user enters an End Date, recalculate Subscription Term from Start/End Date instead.

## Key date math (confirmed from source ticket's bug-fix history)

End Date = Start Date + Subscription Term **− 1 day**. Example: 12-month term starting 16 Dec 2025 → End Date = 15 Dec 2026, not 16 Dec 2026. This off-by-one was an actual bug found and fixed during testing — get this right the first time.

## Steps (confirmed from source ticket)

1. Create a **Formula field** to calculate End Date within the Create Quote screen flow (Start Date + Subscription Term − 1 day).
2. Create a **Trigger flow** to calculate and update Subscription Term on the Quote when End Date is manually changed instead.

**Components:** Screen Flow — Create Quote; Custom Action — New Quote.

## ⚠️ Known limitation

Subscription Term recalculation (when End Date is edited directly) has a **technical limitation** noted directly by the implementer: the recalculated term doesn't always reflect immediately on the quote record after an edit — a page refresh or re-open may be needed. This is a known constraint of the trigger-flow approach, not necessarily a bug to chase if encountered.

## Validation
- [ ] New quote defaults Subscription Term to 12
- [ ] Leaving End Date blank calculates it correctly as Start Date + Term − 1 day
- [ ] Entering End Date manually recalculates Subscription Term correctly
- [ ] Test the specific case that broke before: 12-month term, verify End Date is exactly one day before the anniversary of Start Date
