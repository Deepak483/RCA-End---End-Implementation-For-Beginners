# Module 4 — Quote Management

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Quote Management" (13 items — 12 with Asana tickets, 1 without).

**Prerequisite:** Modules 1–3 complete. Quote Management builds the actual quoting workflow on top of the settings, products, and pricing already configured.

## Data source checkpoint

This module is mostly process/flow/approval logic rather than product data, but two tickets do involve org-specific structures (partner accounts, approval thresholds tied to product categories/pricing). Confirm with the user whether to use the reference approval thresholds and partner setup below, or their own.

## The 13 items

| # | Item | Asana ticket | Depends on |
|---|---|---|---|
| 1 | Quote Creation | [1212235867032641](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032641) | Module 1 (Revenue Management app) |
| 2 | Quote Settings | [1212206597402275](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212206597402275) | Module 1 settings (reinforces item #3 from that module) |
| 3 | Dates on Quote | [1212227290171262](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171262) | Quote Creation |
| 4 | Dates on Quote Line | [1212227290171266](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171266) | Dates on Quote, Module 2 products |
| 5 | Quote Sync | [1212450081485102](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212450081485102) | Quote Creation |
| 6 | Partner Account Population | [1212392771898683](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212392771898683) | Quote Creation, Module 3 Partner Discount |
| 7 | Address on Account | [1212442524927402](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927402) | — (Account-level validation, independent) |
| 8 | Billing/Shipping/Contact on Quote | [1212392771898689](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212392771898689) | Partner Account Population, Address on Account |
| 9 | Discount Approvals | [1212346537317187](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317187) | Module 2/3 products & pricing |
| 10 | Payment Term Approval | [1212346537317197](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317197) | Quote Creation |
| 11 | Submit for Approval Button | [1212346537317193](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317193) | Discount Approvals, Payment Term Approval |
| 12 | Hide Submit Button When Approved/Rejected | [1212346537317195](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317195) | Submit for Approval Button |
| 13 | Transaction Line Editor Fields | *(no Asana ticket — Confluence only)* | Module 2 products |

Run roughly in this order — approvals (9–12) depend on quotes/products/pricing already existing, so do them last.

## Known blockers/limitations to flag upfront

- **Ticket 7 (Address on Account)** is actually tagged `CRM Setup` in Asana's own Module field, not Quote Management — Confluence groups it here because it's a prerequisite for Billing/Shipping population, but if you're tracking work by Asana's Module field elsewhere, expect this discrepancy.
- **Ticket 8:** Billing/Shipping address population from Partner Account had a real bug where only Billing (not Shipping) updated when a partner was added after quote creation — confirm both addresses update, not just one.
- **Ticket 3 (Dates on Quote):** subscription term recalculation from start/end dates has a "technical limitation" noted directly in the ticket — editing the term doesn't always immediately reflect on the quote; check this before assuming a bug in your org.
- **Approval chain naming (Tickets 10–12):** the source org had real routing bugs (Net 30 going to CFO instead of Manager, single-level instead of two-level approval for Net 45/60/90) — test every payment term value, not just one, and confirm the approval chain step names match your actual approver hierarchy labels.

## Files in this module

- `01-quote-creation.md`
- `02-quote-settings.md`
- `03-dates-on-quote.md`
- `04-dates-on-quote-line.md`
- `05-quote-sync.md`
- `06-partner-account-population.md`
- `07-address-on-account.md`
- `08-billing-shipping-address-contact.md`
- `09-discount-approvals.md`
- `10-payment-term-approval.md`
- `11-submit-quote-approval-button.md`
- `12-hide-submit-button-when-approved.md`
- `13-transaction-line-editor-fields.md`

Once all 13 are done, check `ROADMAP.md` for the next module (Order Management).
