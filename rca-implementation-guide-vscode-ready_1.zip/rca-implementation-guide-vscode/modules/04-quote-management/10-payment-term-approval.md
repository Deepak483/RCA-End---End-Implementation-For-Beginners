# 10 — Approval Rule: Payment Term

Source: [Asana ticket 1212346537317197](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317197) — "Quote Management - Approval Rule - Payment Term"

## Goal

Route quote approval based on the Payment Term selected.

### Reference approval matrix (source ticket)

| Payment Term | Level | Approver | Result |
|---|---|---|---|
| Net 15 | Auto | Auto-Approved | Status = Approved, record locked |
| Net 30 | 1 | Manager | Status = In Review, record locked |
| Net 45 / 60 / 90 | 1 | Manager | Status = In Review, record locked |
| Net 45 / 60 / 90 | 2 | CFO | Status = In Review, record locked |

Net 15 auto-approves. Net 30 needs Manager only (single level). Net 45/60/90 need **two** levels — Manager then CFO.

## Steps (confirmed from source ticket)

1. Create a picklist field **Payment Terms** with values: Net 15, Net 30, Net 45, Net 60, Net 90.
2. Build the approval logic into the same **Quote Approval** flow used in `09-discount-approvals.md`, with conditional submission based on Payment Term.
3. Rename the approval steps clearly — the source org named them **Payment Term Level 1** and **Payment Term Level 2** after initial confusion (see known issues).

**Component:** Flow — Quote Approval.

## ⚠️ Known issues from testing — routing bugs, test every term value

Real routing bugs surfaced, not just naming issues:
- Net 15 didn't auto-approve as expected — check this specifically, it's the term most likely to silently fail if the "auto" branch isn't wired correctly.
- Net 30 was routing to CFO instead of Manager — a level mismatch.
- Net 45 wasn't going to 2-level approval at all, and its level-1 step was mislabeled as a CFO approval instead of Manager.
- Root cause in one case was **how managers were assigned** — confirm the approver-resolution logic (e.g. "current user's manager" lookup) is actually configured correctly, not just the approval step count.

**Test every payment term value individually** (Net 15, 30, 45, 60, 90) — this ticket's bug history shows almost every term had a distinct routing problem, so passing on one term doesn't mean the others work.

## Validation
- [ ] Net 15 → auto-approved, status Approved, record locked
- [ ] Net 30 → routes to Manager only, status In Review, record locked
- [ ] Net 45, 60, 90 → route to Manager then CFO (2 levels), status In Review, record locked
- [ ] Approval step names clearly indicate which level/term they belong to
- [ ] Manager assignment resolves to the correct actual manager for the quote owner
