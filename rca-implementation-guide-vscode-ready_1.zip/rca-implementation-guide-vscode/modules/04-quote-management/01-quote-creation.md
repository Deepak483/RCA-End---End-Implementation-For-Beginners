# 01 — Quote Creation (New Quote Button on Opportunity)

Source: [Asana ticket 1212235867032641](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032641) — "Quote Management - Create a New Quote Button on Opportunity"

## Goal

Add a **New Quote** button on the Opportunity that creates a Quote with these fields pre-populated:
- **Quote Name** — user enters
- **Account Name** — auto-populated from the Opportunity's Account
- **Opportunity Name** — auto-populated
- **Start Date** — defaults to today, editable
- **End Date** — user enters

## Steps (confirmed from source ticket)

1. Create a custom action **"New Quote"** on the Opportunity object.
2. Build a **Screen Flow** ("Quote Create" / "Create Quote") that:
   - Reads the Account from the source Opportunity
   - Presents the fields above to the user
   - Creates the Quote record
3. Call the Screen Flow from the custom action.

**Components:** Screen Flow — Create Quote; Custom Action — New Quote.

This is also the foundation flow that later tickets extend (Dates on Quote, Quote Sync, Partner Account Population all modify this same flow rather than building separate ones).

## Validation
- [ ] "New Quote" button visible on Opportunity page layout
- [ ] Clicking it opens the screen flow with Account and Opportunity Name pre-populated
- [ ] Start Date defaults to today and is editable
- [ ] Quote record is created correctly on submission
