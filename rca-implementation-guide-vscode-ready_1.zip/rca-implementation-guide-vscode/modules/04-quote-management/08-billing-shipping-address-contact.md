# 08 — Billing & Shipping Address and Contact on Quote

Source: [Asana ticket 1212392771898689](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212392771898689) — "Quote Management - Update Billing & Shipping Details on Quote"

## Goal

- If the Quote has a Partner Account, populate Billing Address, Bill-To Contact, and Shipping Address from the **Partner** Account.
- If there's no Partner Account, populate all three from the Quote's own **Account** instead.
- User can edit these after they're populated.
- Whichever Contact is marked **Primary** on the relevant account should be stamped as the Quote's contact.

## Steps (confirmed from source ticket)

Modify the **Quote Before Save** flow (a record-triggered flow, not the screen flow used elsewhere in this module — worth noting the mechanism difference) to implement the conditional logic above.

**Component:** Flow — Quote Before Flow.

## ⚠️ Known issues from testing

1. **Partner Account went blank on quote creation** even when set on the creation screen — a real bug, not expected behavior. Verify the Partner field actually persists through quote creation before trusting the address population logic downstream.
2. **Only Billing Address updated, not Shipping**, when a Partner was added to a quote after initial creation. Both addresses need to update together — test adding a partner post-creation specifically, not just at creation time.

## Validation
- [ ] Quote created with a Partner Account: Billing, Shipping, and Bill-To Contact populate from the Partner
- [ ] Quote created without a Partner Account: all three populate from the Quote's own Account
- [ ] Adding a Partner Account *after* quote creation updates both Billing AND Shipping (test this specifically — it was broken in the source implementation)
- [ ] Primary Contact on the relevant account is correctly stamped on the Quote
- [ ] Partner Account field itself persists correctly through quote creation (doesn't go blank)
