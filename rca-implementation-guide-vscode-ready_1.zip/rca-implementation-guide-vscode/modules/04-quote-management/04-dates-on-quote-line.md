# 04 — Dates on Quote Line

Source: [Asana ticket 1212227290171266](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171266) — "Quote Management - Populate Start and End Date on Quote lines"

## Goal

- Quote line items should inherit Start/End Date from the Quote header on creation.
- Dates and term should only populate for **Term Defined** selling models (Monthly, Quarterly, Yearly) — not One-Time.
- For One-Time products: only Start Date populates; End Date stays blank.
- Users can still manually override dates/term on individual lines.
- End Date cannot be removed by the user for any Term Defined product once populated.

## Steps (confirmed from source ticket)

Implemented inside the same Apex pre-hook used for pricing (`ApexDmlDiscountUpdatePreHook`, via Procedure Plan Orchestration — see Module 3, `04-partner-discount.md` for how this mechanism works):
1. The hook reads the Quote's Start Date and End Date and pushes them to each Quote Line Item during Pricing Engine execution.
2. Logic filters by Selling Model Type — only Term Defined - Monthly/Quarterly/Yearly get both dates.
3. One-Time selling model → Start Date only, End Date explicitly skipped.
4. **Amendment, Cancel, and Transfer action types are explicitly excluded** — existing lines in those scenarios keep their dates rather than being overwritten. This matters: don't let this logic run during amendments or it will corrupt already-correct amendment line dates.

## ⚠️ Known issues from testing

- Amendment and Renewal quote lines initially got incorrect dates — required updating the flows specifically for those scenarios (the exclusion in step 4 above is the fix, not an oversight to "correct").
- An off-by-one date bug appeared on renewal quote lines (end date one day off from expected) — same class of bug as `03-dates-on-quote.md`, fixed the same way (verify the −1 day math explicitly).

## Validation
- [ ] Term Defined products get both Start and End Date populated from the Quote header
- [ ] One-Time products get only Start Date
- [ ] End Date cannot be cleared by the user on Term Defined lines
- [ ] Amendment/Renewal/Cancel/Transfer scenarios do NOT have their existing line dates overwritten by this logic
- [ ] Renewal quote line End Date math is correct (test the exact date, not just "looks close")
