# 07 — Address on Account (Mandatory Billing/Shipping Validation)

Source: [Asana ticket 1212442524927402](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927402) — Asana Module field: **CRM Setup** (Confluence groups it under Quote Management as a prerequisite for `08-billing-shipping-address-contact.md`)

## Goal

Require Billing Address and Shipping Address on the Account before it can be saved.

## Steps (confirmed from source ticket)

Create a **Validation Rule** on Account: if Billing Address or Shipping Address is blank, block save with the error message:
> "Please fill Billing and Shipping Address"

**Component:** Validation Rule — `Shipping_and_Billing_Address_is_required` on Account.

## Why this matters for Quote Management

`08-billing-shipping-address-contact.md` populates Quote billing/shipping fields from the Account (when no Partner Account is set). If Account addresses can be blank, that downstream population silently fails. This validation rule is what guarantees the source data exists.

## Validation
- [ ] Attempting to save an Account with blank Billing or Shipping Address is blocked with the expected error message
- [ ] Existing Accounts created before this rule was added — confirm none have blank addresses, or the rule will block any future edit to those records until fixed
