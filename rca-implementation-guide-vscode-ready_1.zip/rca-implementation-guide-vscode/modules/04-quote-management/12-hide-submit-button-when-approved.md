# 12 — Hide "Submit for Approval" Button on Approved/Rejected/In-Review Quotes

Source: [Asana ticket 1212346537317195](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212346537317195) — "Quote Management - Submit for Approval button should not be visible in Approved/In Review Quote"

## The bug this fixes

Without this fix: submitting an already-**Approved** quote for approval again silently resets its status back to **In Review** and creates a duplicate approval record — a real regression risk if the button stays visible after approval.

## Goal

The "Submit for Approval" button (`11-submit-quote-approval-button.md`) should only be visible when the quote is in **Draft** status — not Approved, In Review, or Rejected.

## Steps (confirmed from source ticket)

Add **conditional visibility** to the "Submit for Approval" custom action/button on the Quote Lightning Record Page, filtering on Quote Status = Draft.

**Component:** Lightning Record Page — Quote Record Page.

## ⚠️ Known issue: Rejected quotes needed the same fix

The initial fix only handled Approved/In Review — a follow-up comment specifically called out that **Rejected** quotes still showed the button, and clicking it did nothing useful. Make sure the visibility condition excludes Rejected too, not just Approved/In Review — treat "Draft only" as the rule, rather than enumerating "not this one status."

## Validation
- [ ] Button visible on Draft quotes
- [ ] Button hidden on Approved, In Review, and Rejected quotes (test all three explicitly — Rejected was missed in the first pass)
- [ ] Re-submitting an already-Approved quote is no longer possible through this button
