# 06 — Usage Product Setup

Source: [Asana ticket 1212357267439415](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212357267439415) — "Product Setup - Usage Based", plus the linked Confluence page ["Usage Management - Usage Product Setup and Usage Summary Generation Process"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3040182274/) which has the actual detailed procedure.

This is the longest and most involved ticket in this module — it's a full usage-based billing chain (rating → summary → wallet), not just a product creation step.

## Goal

Configure a usage-based product (reference org used **API Access Management**) so that consumption is tracked, rated, summarized, and reflected as consumed tokens in the customer's wallet.

## Data source checkpoint

If option (a): use API Access Management as the usage product. If option (b): ask the user which product should be usage-based, its unit of measure, and its rate card structure — same steps, different values.

## Full procedure (confirmed from the linked Confluence page)

1. Update **Usage Model Type** to **Anchor** on the product.
2. Create a **Unit of Measure Class** record — don't activate it yet.
3. Create **Units of Measure** under that class, set one as the **Default Unit of Measure**, then activate the class.
4. Create a **Usage Resource** record.
5. Create a **Usage Definition** product — clone the main product and rename it. **Do not** set a Price Book Entry on the definition product.
   > Why a separate definition product: usage must be modeled as a product for pricing, rating, subscription linkage, invoicing, and revenue recognition — it's the billing/pricing anchor that turns raw usage into monetized charges.
6. Create a **Product Usage Grant** record.
7. Create **Rate Card** records for the usage product — one **Base Rate Card**, one **Tier Rate Card**. Set the Effective Date per your requirement (ideally backdated).
8. Create a **Rate Card Entry** related to the Base Rate Card. Set **Effective From** one day after the rate card's effective date.
9. Create the **Tier** Rate Card record.
10. Create a **Rate Card Entry** related to the Tier Rate Card.
11. Create **Rate Adjustment by Tier** records related to that rate card entry.
12. Create **Price Book Rate Card** records for both rate cards (Base and Tier).
13. Refresh these decision tables:
    - Tier-based Rate Adjustment by Rate Card Entry ID
    - Rate Adjustment by Attribute Entries 2
    - Rate Adjustment by Tier Resolution Entries
    - Rate Adjustment by Tier Entries
    - Rate Card Entries
    - Rate Card Entry Resolution Entries 2
    - Rate Card Entry Resolution Entries
    - Rate Card Entries 2
    - Price Book Entries
    - Price Book Entries V2
    - Pricebook Rate Card Entries
14. Create a **Quote** with the usage-based product on it.
15. Add the product to the quote.
16. **Manage Usage Resource** on the quote line:
    - Binding Type = **Target**
    - Binding Target Type = **Account**
    - Binding Target = the Account related to the quote
    - Grant Quantity = per requirement
    - Save
17. Create the **Order** and **Activate** it.
18. Once activated, an **Asset** is created automatically in the background (visible related to the Account).
19. Refresh these decision tables:
    - Asset Rate Card Entry 2
    - Asset Rate 2
    - Asset Volume-based Rate Adjustment 2
    - Binding Object Rate Card Entry 2
    - Binding Object Rate 2
    - Binding Object Volume-based Rate Adjustment 2
    - Volume-based Rate Adjustment by Rate Card Entry ID
    - Commitment-based Rate Adjustment
20. Create a **Transaction Journal** record.
21. Click **Summarize** — this runs a background job and creates a **Usage Summary** record.
22. Click **Calculate Rate** on the Usage Summary page.
23. Run the **Generate Liable Summary** flow manually.
24. Refresh the Usage Summary page — it should now show updated **Debited** and **Overage** units.
25. Check the **Consumed Tokens** on the wallet related to the Account.

## If the Ratable Summary doesn't generate

The source doc includes this fallback — a real gotcha worth keeping:
1. Open the **Negotiable Rating Procedure** from Expression Set.
2. **Save as new** Negotiable Rating Procedure.
3. Open the **Generate Usage Ratable Summary** flow.
4. Update the **RatingProcedureName** flow variable to the new procedure's name.
5. **Save as new** flow, activate it.
6. Run **Generate Liable Summary** again.

## Known issues from the ticket's own testing

- **Wallet not updating with no visible quote error:** usually means a usage-based product was added to the quote without a corresponding usage entry on that line. Every usage-based product on a quote needs its own Manage Usage Resource step (step 16) — adding the product alone isn't enough.
- **Quote line date constraint:** start dates before a certain cutover (the source org used 4 Jan) caused issues — keep usage product line start dates after your org's actual go-live/cutover date.
- **One usage product per quote line at a time in testing:** the source team found configuring multiple usage-based products together caused confusion in wallet updates — verify one at a time before combining.

## Validation
- [ ] Usage Model Type = Anchor on the product
- [ ] Unit of Measure Class active with a Default Unit of Measure
- [ ] Usage Definition product exists (no Price Book Entry)
- [ ] Rate Cards (Base + Tier) and their entries exist, dated correctly
- [ ] All listed decision tables refreshed (both the rate-card set and the asset set)
- [ ] Test quote → order → activate → Asset created automatically
- [ ] Usage Summary generates; Calculate Rate and Generate Liable Summary run without error
- [ ] Consumed Tokens visible on the Account's wallet
