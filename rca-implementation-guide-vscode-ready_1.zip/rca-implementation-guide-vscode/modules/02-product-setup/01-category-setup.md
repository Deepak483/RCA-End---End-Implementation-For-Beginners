# 01 — Category Setup

Source: [Asana ticket 1212206597402284](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212206597402284) — "Product Setup - Create Product Category"

## Goal

When a user hits **Browse Catalog** and selects the catalog, they should see two categories — **Bundle** and **Standalone** — each containing separate products.

**Acceptance criteria:** both categories are visible and selectable when the user clicks Browse Catalog on a Quote.

## Steps (confirmed from source ticket)

1. Go to **App Launcher** → search **Product Catalog Management**.
2. Select **Catalogs**.
3. Select (or create) your catalog — the reference org used one called **Data Catalog**.
4. Click the **Related** tab.
5. Click **New** under Categories.
6. Create two categories: **Bundle** and **Standalone**.

## Data source checkpoint

If following option (a) from the module README (recreate reference data): create a catalog named **Data Catalog** with categories **Bundle** and **Standalone**, matching the source org exactly.

If following option (b) (user's own data): ask the user for their intended catalog name and category structure before creating anything — don't assume "Bundle"/"Standalone" fits their model.

## Known issue from the source ticket (worth avoiding)

The implementer initially found that navigating to the Standalone category showed only one product instead of all expected standalone products. The fix: **each product must be explicitly assigned to its category** — creating the category alone doesn't automatically populate it with existing products. When you create products in later tickets (`02-standalone-products.md`), assign the category on each product record rather than assuming catalog structure alone handles it.

## Validation
- [ ] Catalog exists with both categories
- [ ] Browse Catalog on a Quote shows both Bundle and Standalone as selectable
- [ ] (After products exist) each product appears under its assigned category, not just the catalog root
