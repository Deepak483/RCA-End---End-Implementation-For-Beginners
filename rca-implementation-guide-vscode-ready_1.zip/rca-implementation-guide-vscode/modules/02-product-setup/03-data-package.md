# 03 — Data Package (Bundle Setup)

Source: [Asana ticket 1212205890544564](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212205890544564) — "Product Setup - Create Data Package Bundle Setup"

## Goal

Create a bundle product ("Data Package") with configurable child products, categorized correctly, priced correctly.

## Data source checkpoint

If option (a) (reference data): build exactly the structure below. If option (b): ask the user for their bundle's name, child products, which are required vs. optional, and attributes — use this structure as the template shape.

### Reference bundle structure (source ticket)

**Data Package** (bundle, Subscription Catalog / Data Catalog, priced $8,000–$10,000, Term Based - Yearly):
- Data Cloud Storage (Optional)
- Data Recovery (Optional)
- Data Loss Prevention (Optional)
- Data Hardware (Required)

Data Cloud Storage has two required attributes (built in `04-attribute-setup.md`, but the product itself is created here):
- **Cloud Storage** (Picklist, required): 1000 TB / 2000 TB / 10000 TB
- **Storage Type** (Picklist, required): Standard / Archived

Category placement: Data Cloud Storage, Data Recovery, and Data Loss Prevention go under **Software**; Data Hardware goes under **Hardware**. The bundle itself goes under **Bundle** (from `01-category-setup.md`).

## Steps (confirmed from source ticket)

1. Create the **Data Package** bundle product.
2. Create its **Category**, **Product Selling Model Options**, and **Price Book Entries**, with Product Selling Model = **Term Based - Yearly**.
3. Create the child products: **Data Cloud Storage**, **Data Recovery**, **Data Loss Prevention**, **Data Hardware**.
4. Add each child product under the bundle's **Structure** related tab, marking Data Hardware as Required and the rest Optional.
5. Go to **Setup → Decision Tables**, refresh **Price Book Entry** and **Price Book Entry V2**.
6. Go to **Setup → Product Discovery Settings**, enable **Use Indexed Data for Product Listing and Search**, then click **Create Full Index** and rebuild the index for products.

## A judgment call worth flagging to the user

In the source org, two child products (Data Cloud Storage, Data Loss Prevention) initially ended up pre-selected by default in the bundle — this wasn't an intentional requirement and was removed after a review comment ("It is not mentioned anywhere on the ticket... Let's remove them for now"). Default-selected optional components are easy to introduce accidentally when building bundle structure — confirm with the user whether any child products should be pre-selected before finalizing, rather than leaving whatever the UI defaults to.

## Validation
- [ ] Data Package bundle exists with all 4 child products under Structure
- [ ] Data Hardware is Required; the other three are Optional
- [ ] No child product is pre-selected unless the user explicitly wants that
- [ ] Price Book Entry and Price Book Entry V2 decision tables refreshed
- [ ] Product Discovery full index rebuilt
- [ ] Test quote: adding Data Package shows all child products correctly, priced per the bundle setup
