# Module 2 — Product Setup

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Product Setup" (7 Asana tickets).

**Prerequisite:** Module 1 (RCA Setup and Permissions) must be complete and validated first — Product Setup depends on the cloned Product Discovery Context Definition and the enabled Revenue Cloud settings.

## ⚠️ Before running this module: data source question

Every ticket in this module creates real records — products, categories, catalogs, attributes. The reference org (RCA POC org) has specific example data baked into these tickets: an 8-product catalog with real prices, a "Data Package" bundle with specific child products, specific attribute values, etc.

**Ask the user this before building anything:**

> This module creates actual product/catalog data. Do you want me to:
> **(a)** Recreate the reference org's example data as-is (same products, prices, categories — good for a demo/POC that mirrors the original), or
> **(b)** Use your own product/catalog data (you provide the product list, pricing, categories, attributes)?

If (a): use the reference data included in each ticket file below and in `data/standalone-products-source.csv`.
If (b): pause at each ticket and collect the equivalent data from the user before proceeding — don't silently substitute reference data for their real catalog.

This applies per-ticket, not just once — a user might want their own product list but the same category structure, for example. Confirm scope, don't assume.

## The 7 tickets, in dependency order

| # | Ticket | Depends on | Status in source ticket |
|---|---|---|---|
| 1 | [Category Setup](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212206597402284) | — | Done |
| 2 | [Standalone Products](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212147969482234) | Category Setup | **Blocked** in source org — known pricing bug, see ticket doc |
| 3 | [Data Package](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212205890544564) | Standalone Products, Category Setup | Done |
| 4 | [Attribute Setup](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032635) | Data Package (attributes go on Data Cloud Storage) | Done |
| 5 | [Derived Product Setup](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171270) | Standalone Products | Done |
| 6 | [Usage Product Setup](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212357267439415) | Standalone Products | Done |
| 7 | [Quantity Dependency](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1213989230646936) | Data Package | Done |

Run in this order — later tickets build on earlier ones (e.g. Attribute Setup configures attributes on a product created in Data Package; Quantity Dependency fixes a scaling issue on Data Package's child products).

## A known issue to flag upfront

Ticket 2 (Standalone Products) was marked **Blocked** in the source org due to a real Salesforce platform bug: pricing didn't recalculate correctly for Monthly/Quarterly/Yearly products tied to the "Reprice All" action (Salesforce Case #472307220). If the user hits the same symptom (fixed unit prices not scaling with subscription term), tell them this is a known platform issue, not a setup mistake — check if a fix is available for their release before spending time debugging their own configuration.

## Files in this module

- `01-category-setup.md`
- `02-standalone-products.md`
- `03-data-package.md`
- `04-attribute-setup.md`
- `05-derived-product-setup.md`
- `06-usage-product-setup.md`
- `07-quantity-dependency.md`
- `data/standalone-products-source.csv` — the reference org's 8-product list (option (a) above)

Once all 7 are done, run the module validation at the end of `07-quantity-dependency.md`, then move to the next module in `ROADMAP.md` (Pricing Setup).
