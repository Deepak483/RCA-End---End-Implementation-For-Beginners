# 07 — Quantity Dependency

Source: [Asana ticket 1213989230646936](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1213989230646936) — "Quantity Dependency"

## The problem this fixes

By default, when a bundle's quantity changes, all its child products' quantities scale with it. For **Data Package** (from `03-data-package.md`), that means updating the bundle quantity to 100 also sets every child product — including **Data Hardware** — to quantity 100.

That's wrong for Data Hardware specifically: it's a **One-Time** selling model product, and one-time products' quantity can't be changed during amendments. When the bundle's quantity-scaling tries to update Data Hardware's quantity during an amendment, it breaks.

## Fix

Update the Data Package **Product Option** configuration so Data Hardware doesn't inherit the bundle's quantity changes, while the other (subscription-based) child products still do.

## Steps (confirmed from source ticket)

1. Go to the **Data Package** bundle product.
2. Open **Child Components**.
3. Select and edit **Data Hardware**.
4. Set **Quantity Scaling Method = NONE**.
5. Save.

This is a single-field change, but it's easy to miss if you build the bundle once and never revisit it — especially since the bug only surfaces during **amendments**, not initial quote creation, so it can look fine in early testing.

## Validation
- [ ] Data Hardware's Quantity Scaling Method is set to NONE on the Data Package bundle
- [ ] Test: create a quote with Data Package, change the bundle quantity — confirm Data Cloud Storage / Data Recovery / Data Loss Prevention quantities scale, but Data Hardware's does not
- [ ] Test an amendment scenario specifically (not just initial quote creation) — this is where the original bug appeared
