# 02 — Standalone Products

Source: [Asana ticket 1212147969482234](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212147969482234) — "Product Setup in RCA Org"

**Status in source ticket: Blocked** (known platform pricing bug — see below). Read that section before you invest time debugging.

## Goal

Create the standalone products so a user configuring a quote can see and select them, each with the correct selling model and price.

## Data source checkpoint

**Ask first (if not already answered at the module level):** recreate the reference org's 9 products as-is, or use the user's own product list?

### Reference data (option a) — from the source ticket

Also available as `data/standalone-products-source.csv`:

| Product | Selling Model | Price | Category |
|---|---|---|---|
| Antivirus | Monthly | 10,000 | Software |
| Transform Accelerator | Quarterly | 15,000 | Software |
| Implementation Digital Led Onboarding | Yearly | 5,000 | Service |
| Implementation Lite | Monthly | 8,000 | Service |
| Transform Full Day Session | One-Time | 12,000 | Service |
| API Access Management | Yearly | 6,000 | Software |
| Device Access | Quarterly | 7,500 | Hardware |
| Identity Governance | Monthly | 8,000 | Software |
| Workflows | One-Time | 5,500 | Software |

### If option (b): collect from the user
For each product: name, selling model (Monthly / Quarterly / Yearly / One-Time), price, category. Use the table above as the template shape.

## Steps (confirmed from source ticket)

1. Go to **App Launcher** → search **Product Catalog Management**.
2. Click the **Home** tab → open **Product**.
3. Click **New**. Add Product Code, Product Family, Product Name, Description → **Save**.
4. On the Product record page, go to the **Related** list.
5. Click **New** under **Product Selling Model Options** → select the term (Yearly / Quarterly / Monthly / One-Time as applicable) → **Save**.
6. Scroll down, click **Add Standard Price** under **Price Book Entry**.
7. Select **Standard Price Book**, select the product selling model, add the price → **Save**.
8. Go to **Setup** → search **Decision Table**.
9. Select **Price Book Entries V2** and **refresh** the decision table.
10. Repeat for every product.
11. Assign each product to its category (Bundle/Standalone from `01-category-setup.md`) and add a description and image if needed.

**Components touched:** Product, Product Selling Model Option, Price Book Entry, Catalog, Category.

## ⚠️ Known issues from the source ticket

1. **Pricing bug (why this was Blocked):** monthly/quarterly/yearly product prices didn't scale correctly when the quote term changed — all showed a fixed price regardless of term. Root cause was traced to Salesforce's **Reprice All** action; a support case was raised with Salesforce (Case #472307220). If you hit the same symptom, this is very likely a platform-level issue, not a configuration mistake on your end — check for a fix/patch on your current release before deep-debugging your own setup.
2. **Duplicate-on-click:** clicking "Add" on a product can add it multiple times to the quote instead of just increasing quantity. If this happens, tell users to use the quantity selector rather than repeatedly clicking Add.
3. **Category visibility:** if a product doesn't show up under its intended category filter, double check the category was explicitly assigned on the product record (see `01-category-setup.md` known issue).

## Validation
- [ ] All products exist with correct code/name/description
- [ ] Each product has the correct Selling Model Option(s)
- [ ] Price Book Entries exist with correct prices, and Decision Table (Price Book Entries V2) has been refreshed
- [ ] Each product appears under its assigned category in Browse Catalog
- [ ] Test quote: prices scale correctly when term/quantity changes (if they don't, check the Reprice All issue above before assuming it's a setup error)
