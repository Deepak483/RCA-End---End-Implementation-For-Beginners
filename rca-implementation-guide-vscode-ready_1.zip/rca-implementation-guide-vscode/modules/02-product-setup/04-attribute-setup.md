# 04 — Attribute Setup

Source: [Asana ticket 1212235867032635](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032635) — "Product Setup - Create Attributes on Data Cloud Storage Product"

## Goal

When a user configures a quote and adds **Data Cloud Storage** (created in `03-data-package.md`), they should see two required, configurable attributes.

## Data source checkpoint

If option (a): build the exact attributes below on Data Cloud Storage. If option (b): ask the user which product needs attributes, and what the attribute names/picklist values should be — same steps apply, different values.

### Reference attributes (source ticket)

- **Cloud Storage** — Required, Picklist: 1000 TB / 2000 TB / 10000 TB
- **Storage Type** — Required, Picklist: Standard / Archived

## Steps (confirmed from source ticket)

1. Create picklist records under the **Attribute Picklist** object: one for **Storage Type**, one for **Data Storage** (cloud storage sizing).
2. Create the **Attribute Picklist Values** for each (the picklist options listed above).
3. Create a **Data Storage** record under the **Product Classification** object.
4. On the **Data Cloud Storage** product, update the **Based On** field to reference the Data Storage product classification.

## Validation
- [ ] Both attributes appear on Data Cloud Storage when added to a quote
- [ ] Both are marked Required
- [ ] Picklist values match exactly (1000 TB / 2000 TB / 10000 TB; Standard / Archived)
- [ ] Selecting different attribute values doesn't error out the quote line
