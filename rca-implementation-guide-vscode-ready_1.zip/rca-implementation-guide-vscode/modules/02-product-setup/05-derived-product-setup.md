# 05 — Derived Product Setup

Source: [Asana ticket 1212227290171270](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171270) — "Pricing Setup - Derived Product"

This ticket is tagged under both "Product Setup" and "Pricing Setup" — it creates a new product whose price is *derived* (calculated) from other products' prices, rather than fixed.

## Goal

Create a product ("Data Services") whose price on a quote is automatically calculated as 10% of the combined price of specific other products (Data Recovery, Data Loss Prevention, Data Cloud Storage), rather than a fixed price.

## Data source checkpoint

If option (a): build "Data Services" priced at 10% of the three named Data products. If option (b): ask the user which product should be derived, from which source product(s), and what formula/percentage — same mechanism, different inputs.

## Steps (confirmed from source ticket, this is a precise multi-object setup)

1. Create the derived product — reference org used **Data Services**.
2. On the Product's related list, define its **Product Selling Model** (reference org used Term-Based Yearly).
3. Create a **Price Book Entry** from the Product's related list: set **List Price = 0**, add the Price Book, check the **Is Derived** checkbox, save.
4. Go to **App Launcher** → search **Derived Price** → **New**. Fill in:
   - **Product** — the derived product you created (Data Services)
   - **Product Selling Model** — same as on the derived product
   - **Price Book** — same as on the derived product
   - **Source Product** — the product to calculate price from
   - **Pricing Source** — `Product` (calculates from that product's price) or `Header` (calculates from the quote total)
   - **Formula** — which value to use: `List Price`, `Subtotal`, or `Unit Price`
   - **Derived Pricing Scope** — `Transactional` (current quote product only), `Non-Transactional` (all sold products), or `Both`
5. Set **Effective From** (start date/time), save.
6. Go to **Setup → Decision Tables**, refresh **Derived Pricing Entries** and **Price Book Entries V2**.
7. Go to **Setup → Salesforce Pricing Setup**, find **Sync Pricing Data**, run the sync.
8. Confirm the active **Pricing Procedure** includes a **Derived Price** element, and that this pricing procedure is selected under SF Pricing setup.

**Components touched:** Product, Product Selling Model, Price Book, Derived Price, Decision Table, Pricing Setup.

## Reference calculation (from source ticket testing)

10% × (7000 × 6) = 4200 — confirms the derived price recalculates off the source product's total (unit price × quantity), not just unit price alone. Use this as a sanity check formula when testing your own derived product.

## Validation
- [ ] Data Services (or equivalent) product exists with List Price = 0 and Is Derived checked
- [ ] Derived Price record correctly references source product(s), formula, and scope
- [ ] Decision tables refreshed (Derived Pricing Entries, Price Book Entries V2)
- [ ] Pricing Data synced under Salesforce Pricing Setup
- [ ] Active Pricing Procedure includes the Derived Price element
- [ ] Test quote: adding the derived product recalculates correctly when source product quantity/price changes
