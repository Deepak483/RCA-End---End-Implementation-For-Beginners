# Module 3 — Pricing Setup

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Pricing Setup" (4 Asana tickets).

**Prerequisite:** Module 2 (Product Setup) must be complete — every ticket here prices products/bundles/attributes created there (Data Package, Data Cloud Storage, Data Recovery, Data Loss Prevention, Antivirus).

## Data source checkpoint

Same rule as Module 2: this module sets real prices, discount tiers, and partner-specific discounts. Ask whether to recreate the reference org's pricing exactly, or use the user's own pricing/discount structure, before configuring anything.

## The 4 tickets

| # | Ticket | What it does | Depends on |
|---|---|---|---|
| 1 | [Data Package Pricing](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212228997585105) | Bundle-based price adjustments so Data Package's total reflects its configured child products | Module 2: Data Package |
| 2 | [Attribute Pricing](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032637) | Price varies by Storage Type × Storage attribute combination on Data Cloud Storage | Module 2: Attribute Setup |
| 3 | [Discount Population](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032639) | Volume-based discount tiers on 4 products by quantity | Module 2: Standalone Products |
| 4 | [Partner Discount](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171268) | Partner-account-specific discounts via an Apex pre-hook | Module 2: Standalone Products |

Run in this order — Data Package Pricing first since it revealed a UI quirk (bundle total display) that's easier to understand before layering attribute and volume pricing on top.

## Known issues to flag upfront

- **Bundle total double-counting (Ticket 1):** the Data Package bundle's own line total was initially adding to the quote grand total on top of its child products' totals, inflating the number. Fix: hide/zero the bundle's own line total so only child product prices roll up.
- **Partner discount doesn't clear when partner is removed (Ticket 4):** removing the Partner Account from a quote after discounts were applied doesn't remove the discount, even after Reprice All. The team's fix was a validation rule blocking partner removal/change once set, rather than trying to reverse the discount — if the user wants partner changes to be editable, that gate needs rethinking, not just removed.
- **Volume discount tier math errors (Ticket 3):** several real bugs surfaced during testing (wrong tier picked at boundary quantities, duplicate volume discount entry errors) — test boundary quantities specifically (e.g. exactly 100, exactly 500), not just mid-tier values.

## Files in this module

- `01-data-package-pricing.md`
- `02-attribute-pricing.md`
- `03-discount-population.md`
- `04-partner-discount.md`

Once all 4 are done and validated, move to `modules/04-quote-management/`.
