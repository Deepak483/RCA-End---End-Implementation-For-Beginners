# 03 — Discount Population (Volume-Based Discounts)

Source: [Asana ticket 1212235867032639](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032639) — ticket titled "3" in Asana, "Discount Population" in Confluence

## Goal

Apply volume-based discounts automatically when specific products' quantities fall into defined ranges.

## Data source checkpoint

If option (a): use the reference discount table below. If option (b): ask for the user's own products/quantity tiers/discount amounts.

### Reference discount table (source ticket)

| Product | Quantity | Discount |
|---|---|---|
| Cloud Threat Detection | 100–500 | 5% |
| Cloud Threat Detection | >500 | 10% |
| Data Recovery | 100–500 | 5% |
| Data Recovery | >500 | 10% |
| Data Loss Prevention | 50–100 | $1,000 |
| Data Loss Prevention | >100 | $2,500 |
| Antivirus | 100–500 | 15% |
| Antivirus | >500 | 30% |

Note the mixed discount types — percentage for three products, flat dollar amount for Data Loss Prevention. Don't assume all tiers use the same discount type.

## Steps (confirmed from source ticket)

1. Create **Tiers** in the Price Adjustment Schedule **"Standard Volume Based Adjustment"** for each listed product, matching the quantity ranges and discount values above.
2. Modify the active **Pricing Procedure** to include this schedule.
3. Sync/refresh the **Volume Discount Entries** decision table.

## ⚠️ Known issues from testing — check these specifically

Real bugs surfaced during the source implementation's testing, all around **tier boundaries** and **duplicate entries**:
- At quantity 200, Data Loss Prevention gave $1,000 instead of the correct $2,500 (wrong tier picked).
- At quantity 200, Antivirus gave 5% instead of 15%; at >500 it gave only 10% instead of 30%.
- At quantity 500 (a boundary value), Cloud Threat Detection threw a "Duplicate volume discount entry" error.
- Root cause pattern: tier boundary definitions (inclusive vs. exclusive ranges) and per-selling-model duplication — one bug was traced to price adjustment tier records only existing for the Yearly selling model while the product defaulted to Monthly, so no discount applied at all until Monthly tiers were added too.

**Test explicitly at tier boundaries** (exactly 100, exactly 500, etc.) and **across every selling model the product supports**, not just one quantity per tier on the default selling model — this is where the reference implementation's bugs actually lived.

## Validation
- [ ] Every product/quantity combination in the table above produces the correct discount, tested at boundary values
- [ ] Discount tiers exist for every selling model the product supports (not just one)
- [ ] No "Duplicate volume discount entry" errors at boundary quantities
- [ ] Volume Discount Entries decision table refreshed after any tier changes
