# 02 — Attribute Pricing

Source: [Asana ticket 1212235867032637](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032637) — "Pricing Setup - Attributes on Data Cloud Storage Product"

## Goal

Make Data Cloud Storage's price depend on both attributes created in Module 2 (`04-attribute-setup.md`): **Storage Type** and **Storage**.

## Data source checkpoint

If option (a): use the reference price matrix below. If option (b): ask for the user's own attribute-price matrix.

### Reference price matrix (source ticket)

| Storage Type | Storage | Price |
|---|---|---|
| Standard | 1000 TB | $10,000 |
| Standard | 2000 TB | $15,000 |
| Standard | 10000 TB | $20,000 |
| Archived | 1000 TB | $15,000 |
| Archived | 2000 TB | $20,000 |
| Archived | 10000 TB | $30,000 |

## Steps (confirmed from source ticket)

1. Create these records under the Price Adjustment Schedule **"Standard Attribute Based Adjustment"**:
   - Attribute Based Adjustment Rule
   - Attribute Based Adjustments
   - Attribute Adjustment Conditions
2. Update/verify the active **Pricing Procedure** references the "Standard Attribute Based Adjustment" schedule (object: Pricing Adjustment Schedule).
3. Test: on a quote, click the dropdown above Data Cloud Storage → **Configure** → change the attribute values → save → confirm price updates per the matrix above.

## Validation
- [ ] All 6 price combinations produce the correct price when tested via Configure on a quote line
- [ ] Pricing Procedure correctly references the Standard Attribute Based Adjustment schedule
- [ ] Changing attributes on an existing quote line updates the price without needing to remove/re-add the product
