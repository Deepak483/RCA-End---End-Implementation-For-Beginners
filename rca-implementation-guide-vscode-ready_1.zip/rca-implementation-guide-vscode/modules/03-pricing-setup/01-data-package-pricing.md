# 01 — Data Package Pricing

Source: [Asana ticket 1212228997585105](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212228997585105) — "Pricing Setup - Data Package Product"

## Goal

Price the Data Package bundle so its total reflects the sum of its configured child products, with Data Cloud Storage's contribution varying by the attribute value selected (1000/2000/10000 TB).

## Data source checkpoint

If option (a): use the reference structure below. If option (b): ask for the user's own bundle pricing structure — same mechanism, different numbers.

### Reference pricing (source ticket)

| Component | Price |
|---|---|
| Data Cloud Storage | $10,000 base — varies by Storage attribute: 1000 TB → $10,000 / 2000 TB → $15,000 / 10000 TB → $20,000 |
| Data Recovery | $20,000 |
| Data Loss Prevention | $30,000 |
| Data Hardware | $10,000 |
| **Data Package total (2000 TB config)** | **$75,000** |

## Steps (confirmed from source ticket)

1. Create **Bundle Based Adjustment** records for Data Recovery, Data Loss Prevention, and Data Hardware (these set each child's contribution to the bundle price).
2. Data Cloud Storage's price is handled separately via attribute-based pricing — see `02-attribute-pricing.md`.
3. Test: create an Opportunity → Quote → Browse Catalog → Data Catalog → Bundle category → gear icon on Data Package → Software tab → select Data Recovery → **Update Prices** → confirm prices → Save.

## ⚠️ Known issue: bundle total double-counting

The Data Package bundle's own line initially showed a total that got added on top of its child products' totals, inflating the quote's grand total beyond the expected $75,000 for a 2000 TB configuration. **Fix:** remove/hide the bundle's own total from the total price calculation, keeping only the child products' totals — otherwise the grand total is wrong even though individual line prices look correct.

## Validation
- [ ] Bundle Based Adjustment records exist for Data Recovery, Data Loss Prevention, Data Hardware
- [ ] Test quote at 2000 TB Data Cloud Storage: grand total = $75,000 (not higher, due to the bundle-total bug above)
- [ ] Changing the Storage attribute changes the total correctly (see `02-attribute-pricing.md` for the attribute-price mapping)
