# 04 — Partner Discount on Quote Lines

Source: [Asana ticket 1212227290171268](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212227290171268) — "Partner Discount on Quote Lines"

## Goal

Apply a partner-specific discount to specific products when a quote is created for a particular partner/distributor account.

## Data source checkpoint

If option (a): use the reference partner-discount table below. If option (b): ask for the user's own partner accounts, applicable products, and discount rates.

### Reference partner discounts (source ticket)

| Product | Partner | Discount |
|---|---|---|
| Data Cloud Storage | ABC Software | 15% |
| Data Recovery | ABC Software | 15% |
| Data Cloud Storage | XYZ Cloud | 10% |
| Data Recovery | XYZ Cloud | 10% |

## Why this needs an Apex pre-hook, not just a price adjustment schedule

Partner discounts here run **before** the standard pricing procedure via a **Procedure Plan** with an **Apex section** — this is a materially different mechanism than the attribute/volume pricing in the other 3 tickets, because the discount needs to apply based on which Account is linked as the quote's Partner, which isn't natively something a price adjustment schedule resolves against.

## Steps (confirmed from source ticket)

1. Create records under a custom **Partner Product Discount** object for each product/partner/discount combination above.
2. In **Revenue Settings**, enable **Procedure Plan Orchestration for Pricing**.
3. Search **Procedure Plan Definitions** in Quick Find.
4. Create an **Apex class for the pre-hook** (source org's class: `ApexDmlDiscountUpdatePreHook`).
5. Click **New** to create a Procedure Plan. Fill in:
   - Title, Developer Name
   - Process Type = **Revenue Cloud**
   - Primary Object = **Quote**
   - Context Definition = your context definition (the one cloned in Module 1, ticket 2)
6. Under **Procedure Plan Sections**, click **Add**, select **Standard**, then Section Type = **Apex**.
7. Fill in the section:
   - Phases = **Pricing**
   - Resolution Type = **Default** (or **Rule-Based** if your requirement needs it)
   - Apex = select the pre-hook class from step 4
8. **Activate** the Procedure Plan Definition.

**Component:** `ApexDmlDiscountUpdatePreHook` (Apex class)

## ⚠️ Known issues — real limitations, not just bugs

1. **Discount doesn't clear when Partner is removed.** Removing the Partner Account after a discount has been applied leaves the discount in place — even Reprice All doesn't clear it. This isn't a simple bug to patch; the prehook applies discount at creation-time logic, not as a continuously-reactive calculation.
   **The team's fix was a hard constraint, not a reversal mechanism:** a validation rule blocking the user from removing or changing the Partner Account once set, with the message *"Partner cannot be removed or changed once added. Please create another quote."* If the user wants partner changes to remain editable after the fact, this needs a different technical approach (e.g. re-running the prehook logic on Partner field change), not just removing the validation rule.
2. **Partner discount only applies at quote creation, not on adding a partner to an existing quote's cart.** If a partner is added to a quote *after* it already has products, the prehook logic — since it's tied to quote creation — may not retroactively apply. Confirmed limitation: discount changes require creating quotes with the partner already set, not adding partner mid-build.

## Validation
- [ ] Partner Product Discount records exist for every product/partner combination
- [ ] Procedure Plan Definition is active with the correct Context Definition, Phase (Pricing), and Apex class
- [ ] Test quote created with partner ABC Software + Data Cloud Storage → 15% discount applies automatically
- [ ] Validation rule blocks partner removal/change on a quote where discount has been applied (confirm the message matches what the user wants shown)
