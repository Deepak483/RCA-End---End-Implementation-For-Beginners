# 02 — As-Is Renewals

Source: [Asana ticket 1212450081485122](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212450081485122) — "New Feature - Explore As-Is Renewals"

## What As-Is Renewals does

Locks in the **original price** of an asset through renewal, rather than consolidating to the latest price. Directly controlled by `RevenueManagementSettings.enableAsIsRenewals` — already in the Module 1 settings package, currently `false` (matching the reference org). **Flip to `true` and redeploy if this behavior is wanted.**

## The behavior difference, confirmed by direct testing (worked example from source ticket)

Scenario: a customer buys 1 Laptop at $900 net unit price, then later amends the contract to add 1 more unit at $800 net unit price — one asset, two pricing events over time.

**With As-Is Renewals ON:**
- Renewal quote has **one quote line item** containing **two Quote Line Item Detail records** — one at $900, one at $800.
- Original pricing history is fully preserved.

**With As-Is Renewals OFF (and Asset Pricing Source = Last Transaction Price):**
- Renewal quote **consolidates** to a single line item, quantity 2, priced entirely at $800 (the most recent price).
- The original $900 price is **not preserved.**

## ⚠️ Known issue: blank Net Unit Price is expected, not a bug

Testing found **Net Unit Price disappears on the renewal quote** when As-Is Renewals is enabled (Salesforce Case #472431621 raised). Salesforce Support's confirmed response:
> "The behavior you are observing — where the Net Unit Price is blank on renewals when As-Is Renewals is enabled — is expected. The product team has confirmed that Net Unit Price will be blank when Quote Line Item Details are populated for the quote lines."

**Don't chase this as a bug.** If As-Is Renewals is on and you see blank Net Unit Price with populated Quote Line Item Details underneath, that's the documented, confirmed platform behavior.

## Steps

1. Set `enableAsIsRenewals = true` in Module 1's `RevenueManagement.settings-meta.xml` and redeploy (see `modules/01-rca-setup-and-permissions/scripts/revenue-settings/`).
2. Test the worked scenario above — confirm two Quote Line Item Detail records appear on the renewal, not a consolidated single price.
3. Confirm discounts also carry through correctly in the as-is renewal (this was part of the original exploration scope).

## Validation
- [ ] `enableAsIsRenewals` set to the value the user actually wants (true to preserve pricing history, false to consolidate to latest price)
- [ ] Multi-price-event asset renewal produces multiple Quote Line Item Detail records when enabled
- [ ] Net Unit Price appearing blank on the renewal line is understood as expected (not investigated as a bug) when As-Is Renewals is on
- [ ] Discounts carry through correctly into the as-is renewal
