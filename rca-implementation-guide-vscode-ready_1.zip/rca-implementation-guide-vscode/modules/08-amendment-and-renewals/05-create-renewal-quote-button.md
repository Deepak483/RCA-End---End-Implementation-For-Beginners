# 05 — Create Renewal Quote Button on Renewal Opportunity

Source: Confluence only — **no Asana ticket link exists for this item.**

## Goal (as originally scoped)

A **"Create Renewal Quote"** button on the Renewal Opportunity, which creates a renewal quote containing all renewable assets as quote lines.

## ⚠️ This may already be unnecessary — confirm before building

The Confluence testing comment directly questions whether this button is still needed:
> "I tested (whenever a renewal opportunity is created, quote is automatically created), do we still need button for that?"

This suggests that by the time this item was being tested, quote creation on a Renewal Opportunity had become **automatic** (likely via the same mechanism as `03-renewal-flow.md`'s manual Renew action, or `04-renewal-forecast-opportunity.md`'s process) — making a manual button potentially redundant.

## Recommended approach when doing this in a new org

1. **Test first, build second.** Create a Renewal Opportunity in your new org (via the Renew action from `03-renewal-flow.md`) and check whether a Quote already gets created automatically.
2. If a quote is already auto-created: a "Create Renewal Quote" button may be unnecessary. Confirm with the user whether they still want an explicit manual trigger for some other reason (e.g. re-generating a quote, or use cases where the automatic path doesn't fire) before building it.
3. If no quote is auto-created in your org (behavior may differ by release/configuration): build the button as originally scoped, with the quote pulling all renewable assets as quote lines.

## Validation
- [ ] Confirmed whether renewal quote creation is already automatic in this org before building anything
- [ ] If the button is still wanted: it creates a quote with all renewable assets as quote lines
- [ ] No duplicate quotes get created if both the automatic mechanism and the manual button coexist
