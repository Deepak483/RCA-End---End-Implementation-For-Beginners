# Module 8 — Amendment and Renewals

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Amendment and Renewals" (3 Asana tickets + 2 Confluence-only items).

**Prerequisite:** Modules 1–7 complete — Amendment and Renewal both operate on existing Assets, which depend on everything before this module.

## The 5 items

| # | Item | Asana ticket |
|---|---|---|
| 1 | Explore and Test Standard Amendment Flow | [1212442524927381](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927381) |
| 2 | Explore As-Is Renewals (new Revenue Setting feature) | [1212450081485122](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212450081485122) |
| 3 | Explore and Test Standard Renewal Flow | [1212442524927383](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927383) |
| 4 | Generate Renewal Forecast Opportunity | *(no Asana ticket — Confluence description only)* |
| 5 | Create Renewal Quote Button on Renewal Opportunity | *(no Asana ticket — Confluence description only)* |

## Files in this module

- `01-amendment-flow.md`
- `02-as-is-renewals.md`
- `03-renewal-flow.md`
- `04-renewal-forecast-opportunity.md`
- `05-create-renewal-quote-button.md`

## Direct connection to Module 1's settings package

Item 2 (As-Is Renewals) is the practical, tested explanation of `RevenueManagementSettings.enableAsIsRenewals` — one of the fields already sitting in `modules/01-rca-setup-and-permissions/scripts/revenue-settings/force-app/main/default/settings/RevenueManagement.settings-meta.xml`, currently set to `false` to match the reference org. **If this module's As-Is Renewals behavior is wanted, flip that field to `true` and redeploy** — don't build a separate mechanism.

## Known issues to flag upfront

- **Amendment date bugs** were a real, multi-round back-and-forth in the source org — end dates on amendment quotes initially didn't inherit from the asset's end date at all, then didn't pick the *greatest* end date when multiple assets with different end dates were amended together. Both were fixed, but test multi-asset amendments specifically.
- **As-Is Renewals had two real platform bugs**, both requiring Salesforce Support cases (#472359138, #472431621) — including Net Unit Price actually being *expected* to show blank by Salesforce's own product team once As-Is Renewals populates Quote Line Item Details. Don't treat a blank Net Unit Price as a bug if As-Is Renewals is on — it's documented expected behavior.
- **Auto-Renewal (scheduled, before expiry) is not out-of-the-box** — the source team explicitly concluded "For Auto-Renewal we need to implement the Batch classes and Schedulers," meaning custom Apex batch/scheduler work, not a setting. Don't expect a checkbox for this.
- **Renewal Forecast Opportunity vs. Renewal Opportunity are two different records** — a real point of confusion in testing (someone linked the wrong one). Confirm you're looking at the right object type before troubleshooting either item 4 or item 5.
