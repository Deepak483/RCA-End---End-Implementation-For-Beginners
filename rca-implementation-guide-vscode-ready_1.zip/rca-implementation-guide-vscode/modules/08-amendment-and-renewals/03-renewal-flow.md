# 03 — Explore and Test Standard Renewal Flow

Source: [Asana ticket 1212442524927383](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927383) — "Explore and test standard Renewal Flow"

## Scope tested (confirmed from source ticket)

- Create a renewal from an Asset on the Account
- Auto-renewals a month before asset/contract duration expires
- Generate Orders and a Contract for a renewal quote
- Check renewal pricing: do discounts carry over? Do segments carry over? Can uplift be applied?

## Steps to manually trigger a renewal (confirmed from source ticket)

1. Create a Quote, add products.
2. Generate the Order; fill in Billing Address, Shipping Address, and Bill-To Contact.
3. Activate the Order — an Asset generates automatically under the Account.
4. Select the Asset you want to renew and click **Renew**.

## How to test "a month before expiry" without waiting a month

Create a **backdated quote** — e.g. Start Date 5 Feb 2025, End Date 4 Feb 2026 — then create and activate the order. The resulting Asset will show a lifecycle end date of 5 Feb 2026, letting you test near-expiry renewal behavior immediately rather than waiting on real calendar time.

## ⚠️ Known issue: Auto-Renewal needs custom Apex, not a setting

The exploration concluded explicitly: **"For Auto-Renewal we need to implement the Batch classes and Schedulers."** There is no out-of-the-box toggle that automatically generates a renewal a set period before expiry — this requires building a scheduled Apex batch job. If the user wants true auto-renewal (not just manual "click Renew"), scope this as custom development, not configuration.

## Validation
- [ ] Manual renewal via the Renew button on an Asset works correctly
- [ ] Renewal Order and Contract generate correctly from the renewal quote
- [ ] Discounts carry through to the renewal (cross-check with `02-as-is-renewals.md` for pricing-preservation specifics)
- [ ] If auto-renewal is required: confirmed as custom Apex batch/scheduler work is planned, not assumed to be a configuration toggle
