# 04 — Generate Renewal Forecast Opportunity

Source: Confluence only — **no Asana ticket link exists for this item.**

## Goal

Generate a **Renewal Forecast Opportunity** when Assets are generated. This Opportunity should have the renewable Assets as its Opportunity Products, and its Type field should be stamped **Renewal**.

## ⚠️ Important distinction: Renewal Forecast Opportunity ≠ Renewal Opportunity

The source Confluence comment thread shows this exact confusion happening during testing — someone linked a **Renewal Opportunity** record when asked about the **Renewal Forecast Opportunity**, and had to be corrected with a link to the actual, different record. These are two different objects/records in the reference org. **Confirm which one you're looking at before troubleshooting either this item or `05-create-renewal-quote-button.md`** — the button in that next doc operates on the Renewal Opportunity, not this forecast one.

## What we know vs. what needs confirming

There's no confirmed step-by-step procedure for this item beyond the acceptance criteria — the implementation detail wasn't captured with a "Solution" section the way most other tickets were. The only testing note available says the underlying mechanism ("whenever a renewal opportunity is created, quote is automatically created") was confirmed working, but doesn't explain how the Renewal Forecast Opportunity itself gets generated in the first place.

## Recommended approach when doing this in a new org

1. Determine the trigger: is the Renewal Forecast Opportunity meant to generate at Asset creation time, or on some schedule as assets approach expiry? The name "Forecast" suggests the latter (a pipeline forecasting mechanism), but this isn't confirmed.
2. Build (likely) a Flow or scheduled Apex process that creates an Opportunity, stamps Type = Renewal, and populates Opportunity Products from the renewable Assets — cross-check with `02-as-is-renewals.md` and `03-renewal-flow.md`'s auto-renewal conclusion (custom Apex batch/scheduler) since this may be the same underlying mechanism.
3. Ask the user to confirm the intended trigger timing before building, since this isn't confirmed from the source material.

## Validation
- [ ] Renewal Forecast Opportunity is generated (confirm trigger timing matches what the user actually wants)
- [ ] Type field is stamped Renewal
- [ ] Opportunity Products on the Renewal Forecast Opportunity match the renewable Assets
- [ ] Confirmed you're testing the Renewal Forecast Opportunity specifically, not the (different) Renewal Opportunity from `05-create-renewal-quote-button.md`
