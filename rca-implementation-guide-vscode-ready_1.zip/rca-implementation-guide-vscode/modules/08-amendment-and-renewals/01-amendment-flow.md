# 01 — Explore and Test Standard Amendment Flow

Source: [Asana ticket 1212442524927381](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212442524927381) — "Explore and Test Standard Amendment Flow"

## Scope tested (confirmed from source ticket)

- Amendment from an Asset on an Account
- Cancel an asset from an Account
- Replace a product with a new product
- Close the amendment and reflect updated changes on the Asset and Order

## ⚠️ Known issues — real bugs with confirmed fixes, test these specifically

1. **Ramped product amendment error:** amending an asset for a ramped product threw "Segments have gaps between dates" — this required a Salesforce Support case (Case #472215046... actually tracked separately from the ramp ticket per the comment; treat as a known platform interaction between Amendment and Ramp Deals if you use both). If you're using `enableRampDeal` (Module 1 setting, currently `false` in the reference config) alongside amendments, test this combination explicitly — it's a documented friction point.
2. **Amendment end date didn't inherit from the asset.** Initially, the amendment quote's end date defaulted to 12 months from start date instead of taking the actual asset's end date. **Fix:** the amendment quote's end date should equal the asset's end date; if multiple lines/assets are being amended together, it should take the **greatest** end date among them and stamp that on the quote header. This went through two rounds of fixes before working correctly — test with **multiple assets with different end dates amended in the same transaction** specifically, since that's the scenario that broke the first fix.

## Validation
- [ ] Amendment from an asset works for all 4 scenarios in scope (amend, cancel, replace, close)
- [ ] Single-asset amendment: end date on the amendment quote matches the asset's actual end date (not a recalculated 12-month default)
- [ ] Multi-asset amendment with different end dates: quote end date = the greatest of the assets' end dates
- [ ] If using Ramp Deals, test amending a ramped product specifically for the "Segments have gaps between dates" error
