# 01b — Final Note: The 3 Genuinely Manual-Only Steps

Hand this note to the user once the automated settings (`scripts/revenue-settings/`) are deployed and the #8/#13 build steps (`01a-contract-flow-and-business-rules-setup.md`) are done. These 3 are the ones no script or toggle can complete — confirmed by the absence of any settings field for them, and by Salesforce's own documentation describing them as UI-driven or content-authoring steps.

---

## ✅ Setup checklist — do these 3 manually

### #1 — Enable New Order Save Behavior
**Where:** Setup → Quick Find → `Release Updates` → find "Enable New Order Save Behavior" → **Enable Test Run** → verify → then fully enable (or **Disable Test Run** to revert if something breaks).

**Worth checking first:** Salesforce made this the *default* behavior for all **new** customer orgs starting Winter '25. If this is a genuinely new org (not an older one being upgraded), open Release Updates first — it may already show as enabled and need no action at all.

---

### #7 — Set Up Flow for Managing Assets
**Where:** Setup → Quick Find → `Flows`, or review via the "Automate Asset Creation from Orders" help article.

Unlike #8 (which you build from scratch), Salesforce ships a **standard flow that auto-creates assets when an order is activated** — the products on the activated order become Asset records automatically, out of the box. So the manual step here is smaller than it sounds:
1. Activate a test order and confirm assets are created automatically (this may already work with no changes).
2. If your business needs custom logic (e.g. different asset field mappings, conditional asset creation), clone/customize the standard flow, or use the provided Apex action inside a custom flow.
3. Add the **Managed Asset Viewer** to relevant page layouts so users can see and manage the created assets (see `01a-contract-flow-and-business-rules-setup.md` pattern — Setup → Object Manager → page layout → add component).

Because assets are created automatically by default, don't assume "nothing was set up" if you don't see an explicit toggle — test first before building anything custom.

---

### #14 — Set Up Configuration Rules and Constraints with Constraints Engine
**Where:** Setup → Quick Find → `Revenue Settings` → enable **Set Up Configuration Rules and Constraints with Constraints Engine** (same settings page as #13).

This is Constraint Modeling Language (CML) — genuinely authored content, not a toggle:
1. Enable the setting above.
2. Create a **Constraint Model** — the blueprint defining how your products, attributes, and constraints interact.
3. Define the actual constraints, either:
   - Using the **visual Constraint Builder** (Basic Logic, Conditional Logic, Dynamic Message, Require, Exclude, Hide/Disable, Preference rule types), or
   - Writing them directly in the **CML Editor** for more complex logic.
4. **Sync** the constraint model with your product definitions so it reflects your actual catalog.
5. Run/test the rules via the **Run Config Rules** action (callable from Apex, API, or a screen flow) to confirm behavior before rolling out.

---

## Why these 3 (and only these 3) stay manual

Everything else in the 18-item list reduced to a deployable field once retrieved from a real org. These 3 didn't, for principled reasons:
- **#1** is a Release Update — Salesforce deliberately requires manual review before flipping it, since it changes runtime save logic that could break existing customizations.
- **#7** already has a standard flow doing the heavy lifting; there's no "on/off" because it's not gated — the manual work (if any) is customization, not enablement.
- **#14** is authored logic (CML), conceptually similar to writing a formula or a validation rule — there's no single value that captures "the constraints," because the constraints themselves are the content.

Once these 3 are done, run `06-validation-checklist.md` for the full Phase 1 + Phase 1a sign-off.
