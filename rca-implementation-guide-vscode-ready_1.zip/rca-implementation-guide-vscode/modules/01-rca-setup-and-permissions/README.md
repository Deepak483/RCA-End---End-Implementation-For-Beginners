# Module 1 — RCA Setup and Permissions

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "RCA Setup and Permissions" (3 Asana tickets).

**Trigger phrase:** when a user says "RCA setup & permissions" (or "set up RCA in a new org"), this module runs first, automatically, in this order.

## The 3 tickets

| # | Ticket | What it does | Automation status |
|---|---|---|---|
| 1 | [RCA Setup - Enable Settings & Assign Permission Sets](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212147969366462) | Enable 18 Revenue Cloud settings, assign 51 permission sets | ✅ 12 confirmed automatable, 2 strong candidates, 4 manual (see `01-enable-revenue-settings.md`) |
| 2 | [Clone the Product Discovery Context Definition](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212147969482226) | Clone `ProductDiscoveryContextDefinition` so product visibility/eligibility/pricing rules can be customized | Manual (Setup UI clone action, ~2 min) — see `04-clone-product-discovery-context-definition.md` |
| 3 | [Create a new app 'Revenue Management'](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212688244876534) | Create a custom Lightning app with the Revenue Cloud tabs users need | Manual (App Manager, one-time) — see `05-create-revenue-management-app.md` |

## Files in this module

- `01-enable-revenue-settings.md` — the 18-setting checklist with automation status
- `01a-contract-flow-and-business-rules-setup.md` — manual build steps for 2 of those settings
- `01b-remaining-manual-steps.md` — hand-off note for the 3 fully-manual settings
- `02-permission-set-personas.md` — the 51 permission sets grouped into 6 personas
- `03-assign-permission-sets.md` — how to run the assignment script
- `04-clone-product-discovery-context-definition.md` — ticket 2
- `05-create-revenue-management-app.md` — ticket 3
- `06-validation-checklist.md` — confirm everything from this module worked
- `scripts/` — deployable settings package + permission set assignment script

## Order to run this module

1. `01-enable-revenue-settings.md` → deploy `scripts/revenue-settings/` for the automatable settings, then `01a` and `01b` for the manual ones
2. `02-permission-set-personas.md` + `03-assign-permission-sets.md` → assign permission sets
3. `04-clone-product-discovery-context-definition.md`
4. `05-create-revenue-management-app.md`
5. `06-validation-checklist.md`

Once this module passes validation, move to `modules/02-product-setup/`.
