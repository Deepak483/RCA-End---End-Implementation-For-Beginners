# 01 — Enable Required Revenue Settings (Phase 1)

Source: RCA org setup task, "Enable Required Revenue Settings" — cross-checked against a real retrieval (`sf project retrieve start --metadata "Settings"`) from a source org where all of these were already configured.

**15 of 18 items now have a confirmed or strong-candidate metadata field.** Only 3 are genuinely not reducible to a deployable toggle. See `scripts/revenue-settings/` for the full deployable package with real values pulled from the source org.

| # | Setting | Metadata type | Field | Status |
|---|---|---|---|---|
| 1 | Enable New Order Save Behavior | — (Release Update) | — | **Manual only** — confirmed no settings file exists for this; it's a Release Update requiring Setup → Release Updates → Test Run → Enable. |
| 2 | Enable Revenue Cloud Features | `RevenueManagementSettings` | `enableCoreCPQ` | ✅ Confirmed from source org (`true`) |
| 3 | Set Up Quotes | `QuoteSettings` | `enableQuote` | ✅ Confirmed from source org (`true`) |
| 4 | Add Estimated Taxes to Quotes and Orders | `IncludeEstTaxInQuoteCPQSettings` | `enableQuoteEstimatedTaxCPQ` | ✅ Confirmed from source org (`true`) — exact name match |
| 5 | Advanced Order Creation From Quote | `RevenueManagementSettings` | `enableAdvCreateOrdersFromQuote` | ✅ Confirmed from source org (`true`) |
| 6 | Set Up Orders | `OrderSettings` | `enableOrders` | ✅ Confirmed from source org (`true`) |
| 7 | Set Up Flow for Managing Assets | — | — | **Manual only** — no enablement toggle found anywhere in the retrieval. This is a Flow you build/activate; the Flow itself is deployable metadata once built, but there's no single "on" switch. |
| 8 | Set Up Flow for Creating Contracts from Quotes | `IndustriesSettings` | `enableContractMgmtPref` | ⚠️ Strong candidate (`true` in source org) — unlocks contract management capability, but the actual quote→contract Flow still needs to be built/activated separately. **Manual procedure: `01a-contract-flow-and-business-rules-setup.md`** |
| 9 | Set Up Salesforce Pricing | `IndustriesPricingSettings` | `enableSalesforcePricing` | ✅ Confirmed from source org (`true`) |
| 10 | Set Up Usage Rating | `IndustriesUsageSettings` + `IndustriesRatingSettings` | `enableUsage`, `enableRating` | ✅ Confirmed from source org (both `true`) |
| 11 | Instant Pricing | `RevenueManagementSettings` | `enableRevInstPricingDefaultPref` | ✅ Confirmed from source org (`true`) |
| 12 | Configure Products at Runtime | `ProductConfiguratorSettings` | `enableProductConfigurator` | ✅ Confirmed from source org (`true`) |
| 13 | Set Up Configuration Rules with Business Rules Engine | `IndustriesSettings` | `enablePCMConfigRules` | ⚠️ Strong candidate (`true` in source org) — "PCM Config Rules" = Product Catalog Management Configuration Rules. **Manual procedure: `01a-contract-flow-and-business-rules-setup.md`** |
| 14 | Set Up Configuration Rules and Constraints with Constraints Engine | `IndustriesConstraintsSettings` | — | **Manual only** — the type exists but returned with no fields set in the source org retrieval; this is CML (Constraint Modeling Language) content you author, not a boolean toggle. |
| 15 | Document Builder | `DocumentGenerationSetting` (Custom Metadata record) | `IsServerSideDocGenEnabled` | ✅ Field confirmed via Salesforce Field Reference Guide (not part of the "Settings" retrieval — it's a Custom Metadata record; verify the exact deployment name via a separate `CustomMetadata` retrieve) |
| 16 | Ramp Deals for Lines in Quotes and Orders | `RevenueManagementSettings` | `enableRampDeal` | ✅ Confirmed from source org (`false` — matched, per user decision) |
| 17 | Add Derived Pricing Assets to a Quote or Order | `RevenueManagementSettings` | `enableAutoAddDerivedAsset` | ✅ Confirmed from source org (`true`) |
| 18 | Clone Quotes and Orders | `RevenueManagementSettings` | `enableTransactionCloning` | ✅ Confirmed from source org (`true`) |

## What this means practically

- **12 items** are fully confirmed with real field names *and* real values, straight from a working RCA org.
- **2 items** (#8, #13) have a very strong candidate field that's almost certainly the right lever, but each also involves a manual component (building the actual Flow, or authoring the actual rule/CML content) that no toggle can substitute for.
- **1 item** (#15) has a confirmed field name from Salesforce's docs, just not yet re-verified against this specific org's retrieval (different retrieval mechanism).
- **3 items** (#1, #7, #14) are genuinely not reducible to an "enable" flag, no matter how much research goes into it — a Release Update, a Flow you build, and CML content you author. Treat these as manual steps in the checklist below.

## Working through the manual-only items

**See `01b-remaining-manual-steps.md` for a ready-to-hand-off note** covering #1, #7, and #14 with sourced procedures (including one important heads-up: #1 may already be on by default in a genuinely new org, and #7 ships with a standard flow that often needs no changes at all).

Next: `scripts/revenue-settings/README.md` to actually deploy the confirmed 15, then `01a-contract-flow-and-business-rules-setup.md` for the #8/#13 manual build steps, then `01b-remaining-manual-steps.md` for the final 3 (#1, #7, #14).
