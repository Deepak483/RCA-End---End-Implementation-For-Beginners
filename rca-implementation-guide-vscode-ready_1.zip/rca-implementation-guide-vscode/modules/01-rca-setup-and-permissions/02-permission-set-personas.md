# 02 — Permission Set Personas

Source: RCA org setup task, "Assign Below Permission Sets" (51 permission sets total).

Assigning all 51 permission sets to every user is almost never right — most orgs don't use every module (CLM, DRO, Usage-based pricing, etc. are often adopted in phases), and several of these are meant for **integration/headless users only**, not humans. Below, they're grouped into 6 personas so you assign only what each person or system actually needs.

If you're not using a given module at all yet (see the questionnaire, Q4), skip that whole persona for now — you can always assign it later once that module goes live.

## A. Catalog & Pricing Admin
*Builds and maintains the product/pricing model. Small group, usually 1–3 people.*
- Product Catalog Management Designer
- Product Discovery Admin
- Salesforce Pricing Admin
- Salesforce Pricing Design Time User
- Salesforce Pricing Manager
- Rule Engine Designer
- Product Configuration Rules Designer
- Product Configuration Constraints Designer
- Rate Management: Admin
- Rate Management: Design Time User
- Rate Management: Manager
- Usage Management Design Time
- Omnistudio Admin

## B. Sales & Quoting (runtime)
*Reps and CPQ users building quotes day to day.*
- Product Configurator
- Product Discovery User
- Product Catalog Management Viewer
- Salesforce Pricing Run Time User
- Price and Tax Calculation for Quoting
- Rate Management: Run Time User
- Usage: Design User
- Rule Engine Runtime
- Create Orders from Quotes
- Omnistudio User

## C. Billing & Finance Operations
*Finance/billing team running invoicing, receivables, wallet operations.*
- Billing Admin
- Billing Operations User
- Accounts Receivables Admin
- Wallet Management User
- Submit Transactions and Fulfilment User

## D. Order Fulfillment & Assets
*Ops team handling fulfillment routing and installed assets.*
- Fulfillment Designer
- Fulfillment Manager/Operator
- Assetize Order
- DRO Admin User

## E. Contract Lifecycle & Legal (CLM)
*Legal/deal-desk team managing contracts, clauses, obligations, and document generation.*
- CLM Admin User
- CLM Runtime User
- Clause Designer User
- Obligation Manager
- Obligation User
- DocGen Designer
- DocGen User
- Microsoft 365 Word Designer
- Microsoft 365 Word User

## F. Integration / API Users (headless only — do not assign to human users)
*Assign only to dedicated integration user accounts used by middleware, ERPs, or custom APIs.*
- CreateContract API
- InitiateAmendment API
- InitiateCancellation API
- InitiateRenewal API
- PlaceOrder API
- ProductImport API
- ProductAndPriceConfiguration API
- DRO CallOut Permission Set
- Create Billing Schedules From Billing Transactions API
- Data Pipelines Base User

---

**13 + 10 + 5 + 4 + 9 + 10 = 51** ✓ every permission set from the source task is accounted for in `scripts/permission-sets.csv`, tagged by persona.

This grouping is a sensible starting point based on what each permission set's name implies — not an official Salesforce persona model. Adjust freely for your org's actual team structure before running Phase 2.

Next: `03-assign-permission-sets.md`.
