#!/usr/bin/env bash
#
# assign-permission-sets.sh
#
# Assigns all permission sets belonging to a given persona (from permission-sets.csv)
# to one user in a Salesforce org, using the Salesforce CLI.
#
# WHY THIS SCRIPT EXISTS:
# Permission set LABELS (shown in Setup, e.g. "Billing Admin") are not the same as
# their API DeveloperNames (what `sf org assign permset` needs, e.g. "Billing_Admin").
# This script looks up the real DeveloperName in YOUR org before assigning anything,
# so it works regardless of naming differences between orgs/package versions.
#
# USAGE:
#   ./assign-permission-sets.sh --org <alias> --user <username> --persona "<Persona Name>"
#
# EXAMPLE:
#   ./assign-permission-sets.sh --org my-rca-org --user jane@acme.com --persona "Sales & Quoting"
#
# Persona names must match a value in the `persona` column of permission-sets.csv exactly,
# e.g.: "Catalog & Pricing Admin", "Sales & Quoting", "Billing & Finance Operations",
#       "Order Fulfillment & Assets", "Contract Lifecycle & Legal", "Integration / API Users"
#
# REQUIREMENTS: Salesforce CLI (`sf`) installed and authenticated to the target org.
# This script only ASSIGNS existing permission sets — it does not create or modify them.

set -euo pipefail

CSV_FILE="$(dirname "$0")/permission-sets.csv"
ORG=""
USER=""
PERSONA=""
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --org) ORG="$2"; shift 2 ;;
    --user) USER="$2"; shift 2 ;;
    --persona) PERSONA="$2"; shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

if [[ -z "$ORG" || -z "$USER" || -z "$PERSONA" ]]; then
  echo "Usage: $0 --org <alias> --user <username> --persona \"<Persona Name>\" [--dry-run]"
  exit 1
fi

if [[ ! -f "$CSV_FILE" ]]; then
  echo "Cannot find $CSV_FILE"
  exit 1
fi

echo "== RCA Permission Set Assignment =="
echo "Org:     $ORG"
echo "User:    $USER"
echo "Persona: $PERSONA"
echo

# Pull the permission set labels for this persona from the CSV (skip header, match column 2)
LABELS=$(awk -F',' -v persona="$PERSONA" '
  NR > 1 && $2 == persona { $1=$1; print $1 }
' "$CSV_FILE" | sed "s/^\s*//;s/\s*$//")

if [[ -z "$LABELS" ]]; then
  echo "No permission sets found for persona '$PERSONA'. Check spelling against permission-sets.csv."
  exit 1
fi

FOUND_NAMES=()
MISSING_LABELS=()

while IFS= read -r LABEL; do
  [[ -z "$LABEL" ]] && continue
  # Look up the real API DeveloperName for this label in the target org.
  # Note: Label matching is exact-string; if your org customized a label, adjust the SOQL below.
  RESULT=$(sf data query \
    --query "SELECT Name FROM PermissionSet WHERE Label = '${LABEL//\'/\'\'}' LIMIT 1" \
    --target-org "$ORG" --json 2>/dev/null || echo '{"result":{"records":[]}}')

  API_NAME=$(echo "$RESULT" | grep -o '"Name":"[^"]*"' | head -1 | sed 's/"Name":"//;s/"$//')

  if [[ -z "$API_NAME" ]]; then
    MISSING_LABELS+=("$LABEL")
  else
    FOUND_NAMES+=("$API_NAME")
  fi
done <<< "$LABELS"

echo "Resolved ${#FOUND_NAMES[@]} of $(echo "$LABELS" | wc -l | tr -d ' ') permission sets in this org."
if [[ ${#MISSING_LABELS[@]} -gt 0 ]]; then
  echo
  echo "⚠️  Not found in this org (likely not licensed/installed yet — skipping):"
  printf '   - %s\n' "${MISSING_LABELS[@]}"
fi

if [[ ${#FOUND_NAMES[@]} -eq 0 ]]; then
  echo "Nothing to assign. Exiting."
  exit 0
fi

echo
echo "Will assign the following to $USER:"
printf '   - %s\n' "${FOUND_NAMES[@]}"
echo

if [[ "$DRY_RUN" == true ]]; then
  echo "(--dry-run set, not making any changes)"
  exit 0
fi

read -p "Proceed with assignment? [y/N] " CONFIRM
if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
  echo "Aborted."
  exit 0
fi

for NAME in "${FOUND_NAMES[@]}"; do
  echo "Assigning: $NAME"
  sf org assign permset --name "$NAME" --on-behalf-of "$USER" --target-org "$ORG" || \
    echo "   ⚠️  Failed to assign $NAME — see error above (often means it's already assigned, or a license limit)."
done

echo
echo "Done. Run docs/04-validation-checklist.md to confirm."
