# scripts/

## `permission-sets.csv`
The 51 permission sets from the source setup task, tagged with the persona each belongs to (see `../../02-permission-set-personas.md`). Edit this file if your org's grouping should differ.

## `assign-permission-sets.sh`
Assigns every permission set in a given persona to one user, in one target org. It:
1. Reads the persona's permission set **labels** from the CSV.
2. Looks up each label's real API **DeveloperName** in the target org via SOQL (labels ≠ API names — don't assume they match).
3. Shows you exactly what it resolved and what's missing (missing usually = license/module not provisioned).
4. Asks for confirmation before assigning anything.
5. Assigns via `sf org assign permset`.

### Run it
```bash
chmod +x assign-permission-sets.sh   # first time only

# See what would happen without changing anything:
./assign-permission-sets.sh --org my-rca-org --user jane@acme.com --persona "Sales & Quoting" --dry-run

# Actually run it:
./assign-permission-sets.sh --org my-rca-org --user jane@acme.com --persona "Sales & Quoting"
```

Run it once per user per persona. For a team, loop over your user list, e.g.:
```bash
for u in jane@acme.com bob@acme.com; do
  ./assign-permission-sets.sh --org my-rca-org --user "$u" --persona "Sales & Quoting"
done
```

### Before running against Production
Always test against a sandbox first if one is available. Use `--dry-run` to see the resolved permission set names before committing.

### If a permission set isn't found
That almost always means the underlying RCA module/license isn't provisioned in that org yet (e.g. you don't have DRO or CLM licenses). Confirm with Setup → Installed Packages / your Salesforce AE rather than assuming the script is broken.
