# Automating Phase 1 settings via Metadata API

This folder is a real, deployable SFDX source package covering 15 of the 18 settings from the source checklist — verified against an actual `sf project retrieve start --metadata "Settings"` pull from a working RCA source org, not just documentation.

## What's in here, confirmed

| Source checklist item | File | Field | Value in source org |
|---|---|---|---|
| #2 Enable Revenue Cloud Features | `settings/RevenueManagement.settings-meta.xml` | `enableCoreCPQ` | `true` |
| #3 Set Up Quotes | `settings/Quote.settings-meta.xml` | `enableQuote` | `true` |
| #4 Add Estimated Taxes to Quotes and Orders | `settings/IncludeEstTaxInQuoteCPQ.settings-meta.xml` | `enableQuoteEstimatedTaxCPQ` | `true` |
| #5 Advanced Order Creation From Quote | `settings/RevenueManagement.settings-meta.xml` | `enableAdvCreateOrdersFromQuote` | `true` |
| #6 Set Up Orders | `settings/Order.settings-meta.xml` | `enableOrders` | `true` |
| #9 Set Up Salesforce Pricing | `settings/IndustriesPricing.settings-meta.xml` | `enableSalesforcePricing` | `true` |
| #10 Set Up Usage Rating | `settings/IndustriesUsage.settings-meta.xml`, `settings/IndustriesRating.settings-meta.xml` | `enableUsage`, `enableRating` | `true` / `true` |
| #11 Instant Pricing | `settings/RevenueManagement.settings-meta.xml` | `enableRevInstPricingDefaultPref` | `true` |
| #12 Configure Products at Runtime | `settings/ProductConfigurator.settings-meta.xml` | `enableProductConfigurator` | `true` |
| #16 Ramp Deals | `settings/RevenueManagement.settings-meta.xml` | `enableRampDeal` | `false` — matched to source org per user decision |
| #17 Add Derived Pricing Assets | `settings/RevenueManagement.settings-meta.xml` | `enableAutoAddDerivedAsset` | `true` |
| #18 Clone Quotes and Orders | `settings/RevenueManagement.settings-meta.xml` | `enableTransactionCloning` | `true` |
| #15 Document Builder | `customMetadata/DocumentGenerationSetting.Default.md-meta.xml` | `IsServerSideDocGenEnabled` | Field confirmed via Salesforce docs; not part of this org's Settings retrieval (different mechanism — Custom Metadata, not Settings) |

That's 12 fully confirmed with real values, plus #15 with a confirmed field pending a separate CustomMetadata retrieve to nail the exact deployment name.

## Strong candidates (toggle confirmed, manual piece still required)

| Item | File | Field | Why it's not "fully" automatable |
|---|---|---|---|
| #8 Set Up Flow for Creating Contracts from Quotes | `settings/Industries.settings-meta.xml` | `enableContractMgmtPref` (`true` in source org) | Unlocks contract management capability, but the actual quote→contract Flow logic still has to be built/activated separately — this toggle is a prerequisite, not the whole step. |
| #13 Set Up Configuration Rules with Business Rules Engine | `settings/Industries.settings-meta.xml` | `enablePCMConfigRules` (`true` in source org) | "PCM Config Rules" strongly implies Product Catalog Management Configuration Rules; deploy this, then still author the actual rules. |

## Confirmed manual-only (no toggle exists, by design)

- **#1 Enable New Order Save Behavior** — Release Update, no settings file exists for it at all (confirmed by its absence from the full retrieval). Setup → Release Updates → Test Run → Enable.
- **#7 Set Up Flow for Managing Assets** — no enablement toggle anywhere in the retrieval. You build/activate an actual Flow; nothing to flip.
- **#14 Constraints Engine** — `IndustriesConstraintsSettings` exists as a type but came back with zero fields set in the source org retrieval. This is CML (Constraint Modeling Language) content you author, not a boolean.

## How to deploy

**Always retrieve from the target org first**, even though these values are confirmed — a fresh org may have different defaults, and you want to see what's already there before overwriting.

```bash
# 1. Retrieve current settings from your NEW org (see current values before changing anything)
sf project retrieve start --target-org my-new-org \
  --metadata "Settings" \
  --output-dir ./retrieved-new-org

# 2. Compare against the files in settings/ here — adjust any true/false values
#    you want different from the source org's configuration.

# 3. Deploy
sf project deploy start --target-org my-new-org --source-dir force-app
```

For the Custom Metadata record (#15):
```bash
sf project deploy start --target-org my-new-org \
  --metadata "CustomMetadata:DocumentGenerationSetting.Default"
```
If that member name doesn't match, retrieve `CustomMetadata` from a source org first to get the exact name:
```bash
sf project retrieve start --target-org my-source-org --metadata "CustomMetadata" --output-dir ./retrieved-cmdt
```

### Test in a sandbox first
Same rule as always: try this in a sandbox before Production.

### After deploying
Go back to `../../01-enable-revenue-settings.md` and manually handle #1, #7, #14 (fully manual), and `../../01a-contract-flow-and-business-rules-setup.md` for the build steps on #8 and #13 — none of those are reducible to a script no matter the source.
