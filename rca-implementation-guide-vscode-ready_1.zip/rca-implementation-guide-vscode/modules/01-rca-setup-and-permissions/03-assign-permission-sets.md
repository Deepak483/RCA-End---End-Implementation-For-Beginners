# 03 — Assign Permission Sets (Phase 2, Automated)

This is the part of RCA setup that's actually scriptable. Do this after Phase 1 settings are enabled.

## Steps

1. Confirm prerequisites from `../../docs/00-prerequisites.md` (CLI installed, authenticated to the right org).
2. Confirm your user → persona mapping from the intake questionnaire against `02-permission-set-personas.md`.
3. For each user, run the script once per persona they need:
   ```bash
   cd scripts
   ./assign-permission-sets.sh --org <alias> --user <username> --persona "<Persona Name>" --dry-run
   ```
   Review the output, then re-run without `--dry-run` to actually assign.
4. Repeat for every user/persona pair in your list.
5. For **Integration / API Users**, assign only to the dedicated integration user account(s) — never to a human user's login. These permission sets grant programmatic-only capabilities (create/amend/cancel/renew contracts, place orders, import products, etc.) and mixing them into a human's profile is a common audit finding.

## A note on "automatic setup in the org"

If you're working with an assistant that has a **live, connected Salesforce integration** (not just this CLI script), permission set assignment can also happen directly via API calls that insert `PermissionSetAssignment` records — same effect, no terminal needed. That path still requires:
- explicit confirmation of exactly which permission sets go to which user before anything is written, and
- the same label → API name resolution this script does, since the underlying Salesforce object (`PermissionSet.DeveloperName`) doesn't change based on how you connect to it.

The settings in Phase 1, by contrast, are not exposed as writable API objects in the same way — they stay manual regardless of what's connected.

## Troubleshooting
| Symptom | Likely cause |
|---|---|
| Permission set label not found in org | Module/license not provisioned — check with your Salesforce AE |
| `DUPLICATE_VALUE` error on assign | User already has that permission set — not an error, safe to ignore |
| `LICENSE_LIMIT_EXCEEDED` | You've run out of that permission set license type — request more from Salesforce or reassign from an inactive user |

Next: `04-validation-checklist.md`.
