# 01a — Manual Follow-Up: Contract Flow (#8) and Business Rules Engine (#13)

Both #8 and #13 have a confirmed settings toggle (`IndustriesSettings.enableContractMgmtPref` and `enablePCMConfigRules` — see `scripts/revenue-settings/`), but the toggle only *unlocks* the capability. Each still needs a manual build step. Procedures below are sourced from Salesforce Help.

---

## #8 — Set Up Flow for Creating Contracts from Quotes

Source: Salesforce Help, "Automate Contract Creation from Quotes and Orders."

**Required:** Enterprise, Unlimited, or Developer Edition of Revenue Management, with Transaction Management enabled (i.e. `enableContractMgmtPref` from Phase 1 deployed first). **Permission needed:** Manage Flow.

1. From Setup, in the Quick Find box, enter `Flows`, and select **Flows**.
2. Click **New Flow**.
3. Select **Start from Scratch** and click **Next**.
4. Select **Record-Triggered Flow** and click **Create**.
5. Select **Quote** (or **Order**, if you're building the order-based version) as the object.
6. Select **A record is updated** for the trigger configuration.
7. In the **Set Entry Conditions** section:
   - Condition Requirements: **All Conditions Are Met (AND)**
   - Field: **Status**
   - Operator: **Equals**
   - Value: **Accepted**
8. Save your changes and name the flow (e.g. "Create Contract on Quote Acceptance").
9. Click the **+** to add an element, search for and select **Action**.
10. In the New Action panel, filter by Category and select **Revenue Cloud**.
11. In the action search, select **Create Contract**.
12. Map the **Label** and **Source ID** inputs to the triggering record (Quote or Order object, e.g. `{!$Record.Id}`).
13. Save your changes.
14. Activate the flow.
15. Add the **Contract** field to the Quote Details page layout and the Order Details page layout so users can see the linked contract record.

**Repeat for Order** if you want both a quote-based and order-based version.

---

## #13 — Set Up Configuration Rules with Business Rules Engine

Source: Salesforce Help, "Business Rules Engine Setup," plus Trailhead ("Use Product Configurator with Business Rules Engine").

### Step 1 — Confirm the setting is on
From Setup, Quick Find `Revenue Settings`, confirm **Set Up Configuration Rules with Business Rules Engine** is enabled (this is the `enablePCMConfigRules` toggle from Phase 1).

### Step 2 — Assign permission sets
Business Rules Engine ships with a **Rule Engine Designer** permission set for people who build rules, and a **Rule Engine Runtime** permission set for people/systems that just need to execute them at run time — both are already in this repo's persona list (`02-permission-set-personas.md`, Catalog & Pricing Admin persona for Designer, Sales & Quoting persona for Runtime). If you need a custom variant (e.g. read-only), clone the Rule Engine Designer permission set rather than editing it directly.

### Step 3 — Author the actual rules
This is the part no toggle replaces. In the target org:
1. From the App Launcher, find and open **Rule Libraries**.
2. Open (or create) the rule library relevant to your product configuration logic (e.g. a "Configuration Rules" library).
3. Inside the library, build the rule logic as **Decision Tables** and/or **Expression Sets** — these define things like required/excluded product combinations, validation messages, and default selections.
4. Simulate the rule version to confirm it behaves as expected before rolling out.
5. **Activate** the rule library version. Rules don't take effect until activated.

### Step 4 — Verify
Open a quote, add a product that the new rule should affect, and confirm the expected required/excluded/validation behavior shows up in Product Configurator.

---

## Where this fits in the overall flow

Both of these depend on Phase 1's settings being deployed first (`scripts/revenue-settings/`). Sequence:
1. Deploy Phase 1 settings (includes `enableContractMgmtPref` and `enablePCMConfigRules`).
2. Assign the Rule Engine Designer / Runtime permission sets (Phase 2, already covered in `03-assign-permission-sets.md`).
3. Do the manual build steps above.
4. Validate using `06-validation-checklist.md`.
