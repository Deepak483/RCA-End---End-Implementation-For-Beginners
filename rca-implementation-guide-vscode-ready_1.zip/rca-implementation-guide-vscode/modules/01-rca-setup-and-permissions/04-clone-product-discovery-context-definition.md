# 04 — Clone the Product Discovery Context Definition

Source: [Asana ticket 1212147969482226](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212147969482226) — "RCA Setup - Clone the Product Discovery Context Definition"

## What this does

Configures and clones the Product Discovery Context Definition in Revenue Cloud Advanced to expose the fields needed for:
- Quote-level product visibility and discovery
- Qualification procedures
- Product configuration rules

This ensures accurate product eligibility, filtering, and pricing during product selection in the sales transaction lifecycle. Do this early — Module 2 (Product Setup) depends on product discovery working correctly.

## Steps

Confirmed from the ticket (matches both the description and a developer comment):

1. Go to **Setup**.
2. In the Quick Find box, search **Context Definition**.
3. Select **ProductDiscoveryContextDefinition** under Standard Context Definitions.
4. Click the dropdown menu and select **Clone**.
5. **Activate** the cloned context definition.

That's the whole procedure — it's a short, one-time setup step, not an ongoing configuration.

## Note from the source ticket

The person who implemented this in the reference org noted there's no clear UI indicator confirming the clone succeeded ("Can't figure out if it is cloned, as no option as such which defines... Assuming it is cloned"). To verify definitively:
- Check that a new context definition record appears in the list distinct from the standard one, with your org's naming (typically `ProductDiscoveryContextDefinition_1` or similar).
- Confirm the clone is the one referenced by downstream qualification rules / decision tables, not the original standard one.

## Validation
- [ ] Cloned context definition exists and is Active
- [ ] A test product qualification/discovery flow still works after cloning (e.g. Browse Catalog on a Quote shows expected products)
