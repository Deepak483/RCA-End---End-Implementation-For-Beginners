# 04 — Validation Checklist (Phase 3)

Run through this after Phases 1 and 2 to confirm the setup actually took.

## Settings (Phase 1)
- [ ] Setup → Release Updates: "Enable New Order Save Behavior" shows as **Enabled**, not just "Test Run"
- [ ] Create a test Quote — confirm Instant Pricing shows a price without manual refresh
- [ ] Confirm at least one product shows runtime configuration options (bundles/options)
- [ ] Generate a test document via Document Builder on a Quote — confirms DocGen is live
- [ ] Clone a test Quote and a test Order — confirms clone setting is active
- [ ] If using CLM: create a contract from a quote via the flow — confirms setting #8 worked

## Permission sets (Phase 2)
For 2–3 sample users per persona:
- [ ] Setup → Users → [user] → Permission Set Assignments shows the expected sets
- [ ] Ask the user to actually perform one action tied to their persona (e.g. a Sales & Quoting user creates a quote; a Billing user opens Billing Operations) and confirm no permission errors
- [ ] Confirm no permission sets from **Integration / API Users** ended up on a human account

## Record keeping
- [ ] `CHANGELOG.md` updated with: org, date, who ran it, personas/users covered, anything skipped and why

If anything fails validation, don't move on to the roadmap in `05-roadmap-next-modules.md` — fix it here first; later setup steps build on this foundation.
