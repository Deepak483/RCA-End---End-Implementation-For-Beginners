# 05 — Create a New App 'Revenue Management'

Source: [Asana ticket 1212688244876534](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212688244876534) — "Create a new app 'Revenue Management'"

## What this does

Creates a custom Lightning app named **Revenue Management** with the tab set users need for day-to-day RCA work (quotes, orders, products, assets, etc.), and assigns navigation/tab access to the right profiles.

The source ticket referenced an attached image listing the exact tabs to include, which isn't readable from the ticket text alone. **Ask the user for the tab list** before building this — either they have the original attachment, or they can tell you which standard/custom objects their team needs quick access to (typical candidates: Home, Accounts, Quotes, Orders, Products, Assets, Contracts, Opportunities — confirm rather than assume).

## Steps

1. From **Setup**, go to **App Manager**.
2. Click **New Lightning App**.
3. Name it **Revenue Management**.
4. Add the confirmed list of tabs (ask the user — see note above).
5. Under **User Profiles**, assign access to the profiles that need this app (typically the profiles tied to the personas in `02-permission-set-personas.md` — Sales & Quoting, Billing & Finance Operations, etc.).
6. Save and activate.

## Validation
- [ ] App "Revenue Management" appears in the App Launcher for assigned profiles
- [ ] All confirmed tabs are present and load without errors
- [ ] Users outside the assigned profiles do not see the app (unless intentionally public)
