# 01 — Generate Order from Opportunity

Source: [Asana ticket 1212235867032643](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032643) — "Order Management - Generate Order from Opportunity"

## Goal

When an Opportunity is marked **Closed Won**:
- An Order is generated in **Draft** status
- The Order contains all Order Products mapped from the Quote's lines
- Assets are generated for the related Account

## Steps (confirmed from source ticket)

1. Create a **Flow** that triggers on Opportunity Stage = Closed Won, which generates the Order and Order Products.
2. **Critical prerequisite:** the Quote must be **synced** before marking the Opportunity Closed Won — attempting Closed Won on an unsynced quote throws an error. Sync first, then update the stage.
3. Add the **Order** related list tab to the Opportunity page layout so the generated Order is visible (this wasn't there by default and had to be added explicitly).

**Component:** Flow (no separate named component recorded — Order generation logic).

## Validation
- [ ] Marking a Closed Won Opportunity (with quote already synced) generates an Order in Draft status
- [ ] Order Products on the new Order match the Quote's lines exactly
- [ ] Order is visible under the Opportunity's Related tab
- [ ] Attempting Closed Won on an unsynced quote produces a clear error rather than a silent failure
