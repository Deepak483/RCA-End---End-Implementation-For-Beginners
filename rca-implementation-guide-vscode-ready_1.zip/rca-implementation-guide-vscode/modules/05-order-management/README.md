# Module 5 — Order Management

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Order Management" (3 Asana tickets).

**Prerequisite:** Modules 1–4 complete — this module generates Orders from Quotes that already exist.

## The 3 tickets

| # | Ticket | What it does |
|---|---|---|
| 1 | [Generate Order from Opportunity](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212235867032643) | Auto-creates an Order (with Order Products) when an Opportunity is marked Closed Won |
| 2 | [Populate Billing, Shipping Address, and Billing Contact](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212706667554309) | Carries billing/shipping/contact from Quote to Order automatically |
| 3 | [DRO — Explore on DRO](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212423162125001) | Dynamic Revenue Orchestrator setup for post-fulfillment order changes |

## Files in this module

- `01-generate-order-from-opportunity.md`
- `02-billing-shipping-on-order.md`
- `03-dro-setup.md`

## Known issues to flag upfront

- **Ticket 1** only works if the Quote is **synced** first — marking the Opportunity Closed Won without syncing the quote throws an error. This is a real sequencing dependency, not optional.
- **Ticket 3 (DRO)** is genuinely the most fragile part of this module — the source ticket's own comment history documents a **duplicate asset generation bug** that was still being tracked down. Treat DRO as needing hands-on validation in your specific org, not a "deploy and done" step.
