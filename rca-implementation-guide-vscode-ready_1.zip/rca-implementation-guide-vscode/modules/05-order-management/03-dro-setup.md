# 03 — DRO (Dynamic Revenue Orchestrator) Setup

Source: [Asana ticket 1212423162125001](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212423162125001) — "Explore on DRO"

Linked Confluence page ["RCA Dynamic Revenue Orchestrator (DRO)"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/2863628289/RCA+Dynamic+Revenue+Orchestrator+DRO) is referenced by the ticket but is currently **empty** (placeholder only). Everything below is transcribed from the Asana ticket itself, in the same structure the ticket uses.

## Order Change Scenario

Let's consider an order is generated, activated, and is submitted for fulfillment. Once the order is submitted for fulfillment, the user wants to update the order by increasing the quantity for one of the products. In this case, **amendment is not a valid option** since the order is not fulfilled yet. Hence, we can **change** the order instead.

Fulfillment Order and Fulfillment Order Lines should be generated when an Order is activated.

## Permission Set

**Place Change Order**

(Already included in Module 1's persona list — Order Fulfillment & Assets persona in `modules/01-rca-setup-and-permissions/02-permission-set-personas.md`. Assign to any user who needs to change orders post-fulfillment-submission.)

## Things to check

How will the change on order reflect on the Fulfillment Order and Assets.

## Solution

- **Implementation** — Confluence page link added (see above; currently empty, so treat the ticket text itself as the authoritative source for now).
- **Customization:**
  - Remove the standard screen flow **'Submit Order Flow'** for DRO from the Order Lightning Record Page.
    - This flow calls the **'Submit the order'** standard action.
  - Create a new flow with name **'Submit Order Custom'** (Order After Save flow).
    - After Order is Activated, call **'Submit the order'** standard action.

## Additional setup found necessary during testing (not in the original ticket text, but required to make the above work)

- Set up **Fulfillment Workspace** records for all related products — DRO didn't show the technical product in the plan until this was created.
- Configure **SLA records** for fulfillment tracking.

## ⚠️ Known issues from testing — real, not fully resolved at ticket close

1. **Duplicate asset generation.** The ticket explicitly notes "System is generating duplicate assets" as a known problem needing investigation. **Do not assume this is fixed in your org — validate explicitly** by activating a test order and confirming exactly one asset is created per fulfilled line, not two.
2. **Decomposition Lines constraint:** decomposition lines cannot be created from the RLM App itself — you have to switch to another app to create them. This is described as a genuine feature constraint, not a bug, confirmed with the vendor team.
3. **Asset/decomposition lines are not editable after creation** — only Fulfillment Lines can be edited. If a quantity needs to change after assets/decomposition lines already exist, there's no supported update path through those objects; the change has to go through Fulfillment Lines instead.
4. **SLA status showing "In Jeopardy" incorrectly** — a threshold configuration issue was flagged (10-minute threshold triggering jeopardy status when it shouldn't). Check SLA threshold configuration carefully if you see the same symptom.

## Validation
- [ ] Place Change Order permission set assigned to the right users
- [ ] Standard "Submit Order Flow" screen flow removed from the Order Lightning Record Page
- [ ] "Submit Order Custom" (Order After Save flow) correctly calls "Submit the order" standard action automatically once the Order is Activated
- [ ] Fulfillment Order and Fulfillment Order Lines generate correctly when the Order is activated
- [ ] The change-on-order scenario reflects correctly on the Fulfillment Order and Assets (the "Things to check" item above)
- [ ] Fulfillment Workspace exists for every product that needs DRO fulfillment tracking
- [ ] **Explicitly test for duplicate assets** on order activation — this was an open issue in the source org
- [ ] Confirm decomposition lines are created via the correct app (not RLM App) if your process needs them
- [ ] SLA thresholds produce correct status (not false "In Jeopardy" states)

