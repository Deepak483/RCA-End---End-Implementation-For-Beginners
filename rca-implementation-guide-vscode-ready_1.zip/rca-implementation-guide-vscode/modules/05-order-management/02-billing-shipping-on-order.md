# 02 — Billing, Shipping Address, and Billing Contact on Order

Source: [Asana ticket 1212706667554309](https://app.asana.com/1/170150460447494/project/1212065776249232/task/1212706667554309) — "Order Management - Populate Billing, Shipping Address, and Billing Contact"

## Goal

Populate on the Order automatically:
- **Billing Address** = same as Billing Address on Quote
- **Shipping Address** = same as Shipping Address on Quote
- **Billing Contact** = same as Primary Contact on Quote

## Why this matters

Billing Address, Shipping Address, and Primary Contact are **mandatory to activate an Order**. Without automatic population, every order would need manual data entry before it could be activated — this ticket exists purely to remove that friction.

## Steps

**This ticket closed with a surprising resolution:** when tested, the population was found to be **already automated in the system** — no additional configuration was needed beyond what Module 4 (`08-billing-shipping-address-contact.md`, Quote-level population) and standard Order generation (this module, ticket 1) already provide. The Quote-to-Order carry-through happens natively once the Quote-level fields are populated correctly.

**Practical implication for a new org:** don't build custom logic for this before confirming it's actually missing. Generate a test Order from a Quote that already has Billing/Shipping/Contact populated (per Module 4) and check whether the Order inherits them automatically first.

## Validation
- [ ] Generate an Order from a Quote with Billing/Shipping/Contact already populated
- [ ] Confirm the Order shows the same values without any manual entry or custom automation
- [ ] Only build custom logic here if this native behavior doesn't hold in your org/edition
