# Module 7 — Asset

Source: Confluence ["RCA Implementation in new Org"](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org), row "Asset" — **1 item, no Asana ticket link exists for it.**

**Prerequisite:** Modules 1–5 complete — this describes behavior that's largely a side effect of Order activation configured in Module 5.

## The item

**"Assets should be generated when Order is activated."** Confluence testing comment: "Working as expected." Assignee: Ansh Sharma. No linked Asana ticket, no linked Confluence sub-page, no Solution/Component fields — this is the thinnest-documented item across every module built so far.

## What this actually is

This is largely **not new configuration** — it's the confirmation that Salesforce's standard asset-generation-on-activation behavior (the same behavior referenced in Module 5's DRO ticket, and Module 8's Amendment/Renewal tickets, both of which describe "activate Order → Asset generates automatically") works correctly for the products set up in Modules 2 and 3.

## Recommended approach in a new org

Rather than treating this as a build step, treat it as a **checkpoint**:
1. Create a Quote with a mix of product types (Standalone, Data Package bundle with its child products, Usage-based product).
2. Generate and activate the Order (Module 5).
3. Confirm Assets are created for every eligible product on the Account, matching quantities and configuration (attribute values, bundle structure) from the Order.
4. Cross-check against the **known duplicate-asset issue** flagged in Module 5's DRO ticket (`05-order-management/03-dro-setup.md`) — if DRO is active in your org, verify this checkpoint doesn't produce duplicates before considering the module complete.

## Validation
- [ ] Activating an Order creates exactly one Asset per eligible order line (not zero, not duplicated)
- [ ] Asset attribute values (e.g. Data Cloud Storage's Storage Type/Storage) match what was configured on the Order
- [ ] Bundle structure (Data Package's child products) is reflected correctly across the resulting Assets
- [ ] If DRO (Module 5) is active, re-confirm no duplicate assets appear specifically in that configuration
