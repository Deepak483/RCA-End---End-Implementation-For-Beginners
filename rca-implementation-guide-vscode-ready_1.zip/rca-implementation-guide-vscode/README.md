# RCA Implementation Guide (Revenue Cloud Advanced Setup)

A living, growing guide for setting up **Salesforce Revenue Cloud Advanced (RCA)** in a new org — module by module, matching the real implementation tracked in [Confluence: RCA Implementation in new Org](https://bluvium.atlassian.net/wiki/spaces/Dashboard/pages/3009609730/RCA+Implementation+in+new+Org) and its linked Asana tickets.

**Reference org:** this guide's procedures and example data are sourced from the team's **RCA POC org** (referred to as the "source org" throughout). Update the org alias in scripts and docs when a different reference org is designated.

## How this repo grows

Each row in the Confluence "Module" column becomes a folder under `modules/`, built out ticket by ticket as they're pulled from Asana. Currently built:

- ✅ `modules/01-rca-setup-and-permissions/` — 3 tickets, fully built
- ✅ `modules/02-product-setup/` — 7 tickets, fully built
- ✅ `modules/03-pricing-setup/` — 4 tickets, fully built
- ✅ `modules/04-quote-management/` — 13 items (12 tickets + 1 Confluence-only item), fully built
- ✅ `modules/05-order-management/` — 3 tickets, fully built
- ✅ `modules/06-clm/` — 3 items (2 tickets + 1 Confluence-only item), fully built
- ✅ `modules/07-asset/` — 1 item (no Asana ticket), fully built
- ✅ `modules/08-amendment-and-renewals/` — 5 items (3 tickets + 2 Confluence-only items), fully built
- ⏳ Everything else — see `ROADMAP.md` for what's next (Taxation, CRM Setup, Partner Portal, API, Data Migration)

New modules get added the same way: pull the Confluence row's tickets, fetch each from Asana, document the real procedure (not a guess), flag known issues from the ticket's own testing history, and note where user data/product decisions are needed.

## The trigger phrase

Say **"RCA setup & permissions"** (or "set up RCA in a new org") and the assistant should start `modules/01-rca-setup-and-permissions/` automatically, then move to `modules/02-product-setup/` once Module 1 validates — see `AGENT-PLAYBOOK.md` for the exact flow, including when to pause and ask you questions (data source choices, org details, who needs what access).

## Repo structure

```
rca-implementation-guide/
├── README.md                          ← you are here
├── AGENT-PLAYBOOK.md                  ← the "run this" flow, module by module
├── ROADMAP.md                         ← modules not yet built, in Confluence order
├── CHANGELOG.md                       ← log of what was run, in which org, by whom, when
├── intake/
│   └── setup-questionnaire.md         ← questions to ask before touching the org
├── docs/
│   └── 00-prerequisites.md            ← access, licenses, tools needed before you start
└── modules/
    ├── 01-rca-setup-and-permissions/  ← Module 1 (3 tickets) — settings, permission sets,
    │                                      context definition clone, custom app
    ├── 02-product-setup/              ← Module 2 (7 tickets) — categories, products,
    │                                      bundles, attributes, derived pricing, usage,
    │                                      quantity dependency
    ├── 03-pricing-setup/              ← Module 3 (4 tickets) — bundle pricing, attribute
    │                                      pricing, volume discounts, partner discounts
    ├── 04-quote-management/           ← Module 4 (13 items) — quote creation, dates,
    │                                      sync, partner/address population, approvals
    ├── 05-order-management/           ← Module 5 (3 tickets) — order generation, address
    │                                      carry-through, DRO
    ├── 06-clm/                        ← Module 6 (3 items) — contract setup, approval,
    │                                      DocuSign, clauses, source opportunity, templates
    ├── 07-asset/                      ← Module 7 (1 item) — asset generation on activation
    └── 08-amendment-and-renewals/     ← Module 8 (5 items) — amendment, As-Is renewals,
                                           renewal flow, forecast opportunity, renewal quote
```

## Using this with Claude Code (VS Code)

This repo includes `CLAUDE.md`, which Claude Code reads automatically on every session in this folder — so once it's open in VS Code, you don't need to re-explain the structure each time.

1. Clone the repo and open it in VS Code with the Claude Code extension installed.
2. Start a Claude Code session in the repo root.
3. Either type the trigger phrase naturally (**"RCA setup & permissions"** / "set up RCA in a new org"), or run the slash command **`/rca-setup`** (defined in `.claude/commands/rca-setup.md`) to kick off the same flow explicitly.
4. Claude Code will read `AGENT-PLAYBOOK.md`, run intake questions from `intake/setup-questionnaire.md`, then proceed module by module — pausing for confirmation before anything that writes to your org (settings deploys, permission set assignments).

You'll still need the Salesforce CLI (`sf`) installed and authenticated to your target org yourself — see `docs/00-prerequisites.md`. Claude Code runs the same `sf` commands documented throughout this repo; it doesn't need separate Salesforce credentials beyond what your local CLI session already has.

## Quick start

1. Read `docs/00-prerequisites.md` — confirm access and tools.
2. Go through `intake/setup-questionnaire.md`.
3. Work `modules/01-rca-setup-and-permissions/README.md` end to end.
4. Work `modules/02-product-setup/README.md` end to end — **read its data-source question first**, since this module creates real product/catalog records.
5. Work `modules/03-pricing-setup/README.md` end to end.
6. Work `modules/04-quote-management/README.md` end to end.
7. Work `modules/05-order-management/README.md` end to end.
8. Work `modules/06-clm/README.md` end to end — **read its data-source question first** (reference MSA vs. your own contract templates).
9. Work `modules/07-asset/README.md` — mostly a validation checkpoint, not new build work.
10. Work `modules/08-amendment-and-renewals/README.md` end to end — note the direct link back to Module 1's `enableAsIsRenewals` setting.
11. Log the run in `CHANGELOG.md`.
12. Check `ROADMAP.md` for what's next.
