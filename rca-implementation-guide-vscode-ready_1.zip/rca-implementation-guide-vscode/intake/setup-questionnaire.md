# Setup Questionnaire

Answer these before starting Module 1. Keep answers in this file (or paste them into `CHANGELOG.md` once done) so there's a record of what was decided.

## 1. Org details
- Org alias / username you'll authenticate with:
- Environment type: ☐ Sandbox ☐ Production ☐ Scratch org
- My Domain URL:
- Salesforce edition / do you have Revenue Cloud Advanced licenses provisioned already? ☐ Yes ☐ No / not sure
- Reference org for comparison: this repo's example data/config is sourced from the **RCA POC org** — flag here if a different reference org should be used instead, so scripts/docs referencing "the source org" get updated accordingly.

## 2. Access
- Do you (or someone available now) have System Administrator profile access? ☐ Yes ☐ No
- Is Salesforce CLI (`sf`) installed and authenticated to this org? ☐ Yes ☐ No ☐ Not sure
  → if No/Not sure, see `docs/00-prerequisites.md` first

## 3. Product/catalog data source (relevant from Module 2 onward)
Module 2 (Product Setup) and later modules create real product, catalog, and pricing records. Before starting those modules:
- ☐ Recreate the reference org's example data as-is (good for demos/POCs matching the original)
- ☐ Use our own product/catalog data (list of products, pricing, categories, attributes)
- ☐ Mixed — will confirm per module/ticket

## 4. Who needs access (permission sets)
List the people/teams to set up, and which persona from `modules/01-rca-setup-and-permissions/02-permission-set-personas.md` fits each. Example:

| User | Persona(s) | Notes |
|---|---|---|
| jane@acme.com | Sales & Quoting | New AE |
| finance-ops@acme.com | Billing & Finance Ops | |
| integration-user@acme.com | Integration/API User | headless user for middleware |

If you're not sure who needs what yet, that's fine — permission sets can be assigned persona-by-persona as people are identified, it doesn't need to happen all at once.

## 5. Scope check
- Are you using all of: Billing, CLM/Contracts, DRO (Digital Order Routing), Usage-based pricing, Partner/Omnistudio? ☐ All ☐ Some (list which) ☐ Not sure yet
  → this determines which permission sets actually apply to you, and which later modules (Roadmap) you'll need built out first.

## 6. Timing / risk
- Is this org actively used by end users right now, or pre-go-live? ☐ Live ☐ Pre-go-live
  → if Live, Module 1 settings changes should go through your normal change window, not be applied ad hoc.
