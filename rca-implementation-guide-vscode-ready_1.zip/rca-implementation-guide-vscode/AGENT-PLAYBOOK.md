# Agent Playbook — "RCA setup & permissions"

This file defines what an assistant should do when a user gives a command like:

> "RCA setup & permissions" / "Set up RCA in a new org" / "Run the RCA setup"

Follow these phases **in order**. Do not skip intake. Do not execute anything against a live org without the user explicitly confirming the specific action. Modules run in the order they appear in `ROADMAP.md` / the Confluence source — currently Module 1, then Module 2, then whatever's built next.

---

## Phase 0 — Intake (always first)

Open `intake/setup-questionnaire.md` and confirm: org identifier, environment (sandbox/production), and whether someone with System Admin access is available (Module 1's settings can't be done via API alone). If the user has already answered any of this in conversation, don't re-ask — just confirm your understanding.

**Stop condition:** don't proceed to Module 1 until org + environment + access are confirmed.

---

## Module 1 — RCA Setup and Permissions

Trigger: this is what "RCA setup & permissions" means literally — start here.

Open `modules/01-rca-setup-and-permissions/README.md` and work through its 3 tickets in order:
1. Enable Revenue Settings + assign Permission Sets (the big one — 15 of 18 settings automatable, see that folder's own docs for the automation/manual split)
2. Clone the Product Discovery Context Definition
3. Create the Revenue Management app

For ticket 3, the user needs to tell you the tab list (the original ticket's tab list was in an image attachment that isn't machine-readable) — ask rather than guessing a plausible-looking tab set.

Run `06-validation-checklist.md` before moving on. Log progress in `CHANGELOG.md`.

---

## Module 2 — Product Setup

Only start this after Module 1 validates — Product Setup depends on the cloned context definition and enabled settings.

**Before touching anything in this module**, ask the data-source question from `modules/02-product-setup/README.md`:
> Recreate the reference org's example data as-is, or use your own product/catalog data?

This isn't a one-time question if the user's answer is mixed (e.g. "use my own products but the same category structure") — confirm scope per ticket if there's any ambiguity, don't silently substitute reference data for a real customer's catalog. **Ask again at each individual data-creating ticket** (Category Setup, Standalone Products, Data Package, Attribute Setup) rather than treating one answer at the top of the module as covering all of them — a user might want their own product names but the reference categories, for example.

Work the 7 tickets in the dependency order listed in that module's README:
1. Category Setup
2. Standalone Products (flag the known Reprice All pricing bug if the user hits scaling issues)
3. Data Package
4. Attribute Setup
5. Derived Product Setup
6. Usage Product Setup (the long one — 25+ steps, includes a fallback procedure if Ratable Summary doesn't generate)
7. Quantity Dependency

Validate at the end of `07-quantity-dependency.md`. Log progress in `CHANGELOG.md`.

---

## Module 3 — Pricing Setup

Only start after Module 2 validates — every ticket here prices products/bundles/attributes created there.

Ask the data-source question again if it wasn't already settled with a "mixed" answer in Module 2 — pricing structures (discount tiers, partner discounts) are a separate decision from product/catalog structure even when the same overall choice applies.

Work `modules/03-pricing-setup/README.md`'s 4 tickets in order:
1. Data Package Pricing (watch for the bundle-total double-counting issue)
2. Attribute Pricing
3. Discount Population (test tier boundaries explicitly — this is where the reference org's real bugs were)
4. Partner Discount (uses an Apex pre-hook via Procedure Plan Orchestration — a different mechanism than 1–3; flag to the user that Partner removal is blocked once a discount applies, unless they want that constraint redesigned)

---

## Module 4 — Quote Management

Only start after Module 3 validates. This is the largest module (13 items) and mostly extends a small number of flows rather than building many independent ones — most of tickets 1, 3, 5, 6 modify the *same* "Create Quote" screen flow, and tickets 9–10 modify the *same* "Quote Approval" flow. Don't treat each ticket as fully independent; check whether the flow being modified already exists before assuming you're building from scratch.

Work `modules/04-quote-management/README.md`'s 13 items in order. Two callouts:
- Item 7 (Address on Account) is tagged "CRM Setup" in Asana's own Module field, not Quote Management — don't be thrown by the mismatch with Confluence's grouping.
- Item 13 (Transaction Line Editor fields) has **no Asana ticket** — only Confluence description. Treat its steps as "verify in your org first," not confirmed procedure, and say so explicitly to the user rather than presenting it with the same confidence as the other 12.

Approval tickets (9–12) have a real history of routing bugs in the reference org — when implementing, test every input value (every payment term, boundary discount percentages) rather than one happy-path case per ticket.

---

## Module 5 — Order Management

Only start after Module 4 validates. Ticket 1 (Generate Order from Opportunity) has a hard prerequisite: **the quote must be synced before marking the Opportunity Closed Won**, or it errors. Ticket 2 turned out to already work natively in the source org once Quote-level fields were populated — test before building anything custom. Ticket 3 (DRO) is the least stable part of this module — its own ticket documents an open duplicate-asset bug; validate explicitly rather than assuming it's fixed.

---

## Module 6 — CLM (Contract Lifecycle Management)

Only start after Module 5 validates. Ask the data-source question from `modules/06-clm/README.md` — the reference org built clauses from a previous POC's MSA document; confirm whether the user wants that same reference content or their own. Flag the known Asset-Contract relationship gap (spun into a separate untracked follow-up in the source org) rather than promising it's covered.

---

## Module 7 — Asset

Only start after Module 6 validates. This module is a **validation checkpoint**, not new build work — confirm asset generation on order activation works correctly across product types (standalone, bundle, usage), and specifically re-check for the duplicate-asset issue flagged in Module 5 if DRO is active.

---

## Module 8 — Amendment and Renewals

Only start after Module 7 validates. Two things worth surfacing to the user before building:
- **As-Is Renewals is a direct flip of a setting already in the Module 1 package** (`enableAsIsRenewals` in `RevenueManagement.settings-meta.xml`, currently `false`) — don't build new mechanism, redeploy that file with the value changed.
- **True scheduled auto-renewal requires custom Apex** (batch + scheduler) — the reference team explicitly concluded there's no out-of-the-box toggle for this. Set expectations accordingly if the user assumes it's a checkbox.

Items 4 and 5 in this module have no Asana ticket and meaningful open questions in the source material (e.g. whether the "Create Renewal Quote" button is even still needed once automatic quote creation was observed) — present these as things to verify in the target org, not confirmed procedure.

---

## Later modules

Not yet built. Check `ROADMAP.md` — when the user wants the next module (Taxation, CRM Setup, Partner Portal, API, Data Migration), pull that Confluence row's tickets from Asana the same way Modules 1–8 were built, and add a new `modules/0N-name/` folder following the same pattern: README with ticket table + dependency order, one doc per ticket with confirmed steps and known issues, a data-source checkpoint wherever records get created.

---

## Guardrails for the assistant running this

- Never guess at permission set API names, product data, or click paths — pull from the actual Asana ticket / linked Confluence doc, the way every existing module doc does. If a ticket references an attachment/image you can't read, ask the user rather than inventing plausible content.
- **Any step that requires data — product lists, category structures, attribute values, pricing, discount tiers, contract clauses, or similar — must ask the user first: provide your own list, or use the existing reference data already documented in this repo?** This applies everywhere data is required, not just the modules that call it out explicitly: Category Setup, Standalone Products, Data Package, Attribute Setup, Derived Product Setup, Usage Product Setup, and Pricing Setup's four tickets all create real records. Don't default to the reference org's data silently, and don't ask once at the top of a module and assume it covers every ticket inside it — confirm per data-creating step if there's any ambiguity about scope, the same way Module 2 and Module 6 already do explicitly.
- **Before executing a module, check whether its source Confluence page has been updated since this repo's docs were written — don't assume the repo's copy is still current.** Fetch the relevant Confluence page (and any linked sub-pages) fresh and compare against what's documented here. If content has changed (new tickets added, steps revised, links updated), treat the freshly-fetched Confluence data as authoritative, update the module's docs to match, and note the change in `CHANGELOG.md`. Do this at the start of a module, not just once at the start of a whole run — Confluence rows can be edited independently and asynchronously as the underlying implementation evolves.
- Treat any step that creates or modifies org data as a write action: state the plan, get explicit confirmation, then execute.
- Surface known issues from a ticket's own comment history (bugs, platform limitations, gotchas) rather than presenting a clean-room procedure that hides what actually went wrong in the reference implementation — those comments are often more useful than the original ticket description.
- If the org is Production, double-check the user actually intends Production and not a sandbox first.
