# CLAUDE.md

This file is read automatically by Claude Code at the start of every session in this repository. It exists so that opening this repo in VS Code (or any Claude Code surface) and giving a short trigger phrase is enough to start executing the RCA implementation — no need to re-explain the project structure each time.

## What this repo is

A module-by-module implementation guide for **Salesforce Revenue Cloud Advanced (RCA)**, built from a Confluence page and its linked Asana tickets. Each module is a real, sourced procedure — confirmed steps, known bugs from the original implementation's testing history, and validation checklists. Nothing in here is a generic best-practices guess; it's transcribed from an actual implementation.

## Where to start

**Read `AGENT-PLAYBOOK.md` first, every session.** It defines the phase-by-phase flow: intake questions → Module 1 → Module 2 → ... → Module 8, plus the guardrails below. Don't skip straight to a module's steps without going through intake if this is a new org.

## Trigger phrases

- "RCA setup & permissions" / "set up RCA in a new org" → start at Module 1, per `AGENT-PLAYBOOK.md`
- "build the next module" / "add [module name]" → see `ROADMAP.md` for what's not yet built, and the "How to build the next module" section there for the process (pull Asana tickets, document real steps, flag known issues, don't invent generic procedure)

## Repo structure

```
rca-implementation-guide/
├── CLAUDE.md                          ← this file
├── README.md                          ← human-facing overview
├── AGENT-PLAYBOOK.md                  ← the execution flow, read this first
├── ROADMAP.md                         ← built vs. not-yet-built modules
├── CHANGELOG.md                       ← log every real run here
├── intake/setup-questionnaire.md      ← org/environment/data-source questions
├── docs/00-prerequisites.md           ← access, licenses, Salesforce CLI setup
└── modules/01-rca-setup-and-permissions/ through 08-amendment-and-renewals/
```

## Non-negotiable guardrails (also in AGENT-PLAYBOOK.md — repeated here since this file loads automatically)

- **Never guess at permission set API names, product data, or click paths, or field names.** Every confirmed step in this repo was pulled from an actual Asana ticket, Confluence page, or a live org's metadata retrieval. If a module doc says something is unconfirmed ("verify in your org first"), treat it that way — don't upgrade it to confident procedure on your own.
- **Any step that requires data — product lists, categories, attributes, pricing, discount tiers, contract clauses, or similar — must ask the user first: their own list, or the existing reference data already in this repo?** This applies at every data-creating ticket, not once per module — Category Setup, Standalone Products, Data Package, Attribute Setup, Derived Product Setup, Usage Product Setup, and all of Pricing Setup create real records. Confirm scope per step rather than assuming one earlier answer covers everything downstream.
- **Check the source Confluence page for updates before executing a module — don't assume this repo's docs are still current.** Fetch the relevant Confluence page (and linked sub-pages) fresh at the start of each module. If it's changed since these docs were written, treat the fresh Confluence content as authoritative, update the module's docs to match, and log the change in `CHANGELOG.md`.
- **Treat any org-modifying command as a write action.** State exactly what will change (which settings, which permission sets, which records) and get explicit confirmation before running `sf project deploy start`, `sf org assign permset`, or anything that touches a live org — sandbox or production.
- **Sandbox before production, always**, unless the user explicitly confirms otherwise for a specific action.
- **Surface known issues, don't hide them.** Every module doc has a "known issues" section pulled from the real implementation's bug history. When walking a user through a module, mention these proactively — they're often more useful than the clean procedure, because they're the things that actually go wrong.
- **The reference org is the RCA POC org.** Values in `modules/01-rca-setup-and-permissions/scripts/revenue-settings/` reflect that org's actual configuration. If the user is working against a different reference org, flag that the settings package may need updated values, not just a different org alias.
- **Data-source checkpoints are real decisions, not formalities.** Several modules (Product Setup, Pricing Setup, CLM) create actual records. Always ask whether to recreate the reference org's example data or use the user's own before generating anything — see each module's README for the specific question.

## Salesforce CLI conventions used throughout this repo

- Org alias flag: `--target-org <alias>` (not `-u`, matches the current `sf` CLI, not legacy `sfdx`)
- Settings deploy: `sf project deploy start --source-dir force-app`
- Settings retrieve (do this before any deploy): `sf project retrieve start --metadata "Settings" --output-dir ./retrieved`
- Permission set assignment: `sf org assign permset --name <API DeveloperName> --on-behalf-of <user> --target-org <alias>`

## Extending this repo

New modules follow the exact pattern of Modules 1–8: a README with a ticket table and dependency order, one doc per ticket/item with confirmed steps transcribed from the source (not paraphrased into generic advice), a "known issues" section pulled from real comment history, and a validation checklist. See `ROADMAP.md` for what Confluence rows/Asana Module tags aren't built yet.
