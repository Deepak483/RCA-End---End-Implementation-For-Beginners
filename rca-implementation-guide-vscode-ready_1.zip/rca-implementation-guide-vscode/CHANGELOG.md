# Changelog

Log every setup run here. Copy the template for each new org/run.

---

## Template
- **Date:**
- **Org:** (alias / My Domain)
- **Environment:** Sandbox / Production / Scratch
- **Run by:**
- **Phase 1 (settings):** ☐ Complete ☐ Partial (list skipped items + why)
- **Phase 2 (permission sets):** personas/users covered:
  -
- **Skipped / deferred:**
- **Decisions made (where new org differs from source org reference):**
  - e.g. #16 Ramp Deals: matched source org (`false`)
- **Notes:**

---
