Start the RCA implementation flow for this org, following `AGENT-PLAYBOOK.md` exactly:

1. Read `AGENT-PLAYBOOK.md` and `ROADMAP.md` to confirm current module coverage before doing anything else.
2. Run Phase 0 intake: open `intake/setup-questionnaire.md` and ask the user for org identifier, environment (sandbox/production), and access confirmation. Do not proceed past this without those answers — if the user already gave any of this in the conversation, confirm your understanding instead of re-asking.
3. Start Module 1 (`modules/01-rca-setup-and-permissions/README.md`) and work through it in the order its README specifies.
4. Continue to each subsequent module only after the prior module's validation checklist passes, per `AGENT-PLAYBOOK.md`.
5. At every data-source checkpoint — Category Setup, Standalone Products, Data Package, Attribute Setup, and every other data-creating ticket, not just once per module — ask explicitly whether to use the reference org's example data or the user's own. Do not assume.
6. At the start of each module, fetch the module's source Confluence page (and linked sub-pages) fresh and check for updates since this repo's docs were written. If it's changed, treat the fresh content as authoritative, update the module's docs, and note the change in `CHANGELOG.md`.
7. Before any command that writes to the org (`sf project deploy start`, `sf org assign permset`, or similar), state exactly what will change and get explicit confirmation first.
8. Log completed work in `CHANGELOG.md` using its template.

If the user says something other than "start" or confirms a specific module/ticket instead, jump directly to that module's README rather than restarting from Module 1.
